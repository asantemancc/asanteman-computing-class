// ==========================================
// ASANTEMAN COMPUTING CLUB
// PROJECTS PAGE
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
    collection,
    addDoc,
    getDocs,
    query,
    where,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";


// ==========================================
// 1. DOM ELEMENTS
// ==========================================

const sidebarToggle = document.getElementById("sidebarToggle");
const sidebar = document.querySelector(".member-sidebar");
const overlay = document.querySelector(".sidebar-overlay");

const logoutButton = document.getElementById("projectsLogout");

const projectForm = document.getElementById("projectForm");
const projectSubmissionForm = document.getElementById("projectSubmissionForm");

const showProjectFormButton = document.getElementById("showProjectForm");
const submitProjectButton = document.getElementById("submitProjectButton");

const projectsGrid = document.getElementById("projectsGrid");
const projectSearch = document.getElementById("projectSearch");

const totalProjectsElement = document.getElementById("totalProjects");
const myProjectsElement = document.getElementById("myProjects");
const projectCategoriesElement = document.getElementById("projectCategories");


// ==========================================
// 2. SIDEBAR
// ==========================================

function openSidebar() {
    sidebar?.classList.add("active");
    overlay?.classList.add("active");
}

function closeSidebar() {
    sidebar?.classList.remove("active");
    overlay?.classList.remove("active");
}

sidebarToggle?.addEventListener("click", openSidebar);
overlay?.addEventListener("click", closeSidebar);


// ==========================================
// 3. LOGOUT
// ==========================================

logoutButton?.addEventListener("click", async () => {
    try {
        await signOut(auth);
        window.location.href = "login.html";
    } catch (error) {
        alert("Unable to log out. Please try again.");
        console.error(error);
    }
});


// ==========================================
// 4. PROJECT FORM VISIBILITY
// ==========================================

showProjectFormButton?.addEventListener("click", () => {
    if (!projectForm) return;

    projectForm.classList.toggle("active");

    if (projectForm.classList.contains("active")) {
        projectForm.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
});


// ==========================================
// 5. HELPER: SAFE HTML
// ==========================================

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => {
        const replacements = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        };

        return replacements[character];
    });
}


// ==========================================
// 6. PROJECT DATA
// ==========================================

let currentUser = null;
let currentMemberName = "Member";

let myProjects = [];
let activeCategory = "all";
let searchTerm = "";


// ==========================================
// 7. LOAD MEMBER PROJECTS
// ==========================================

async function loadProjects() {
    if (!currentUser) return;

    projectsGrid.innerHTML = `
        <p class="empty-message">Loading your projects...</p>
    `;

    try {
        const projectsQuery = query(
            collection(db, "projectSubmissions"),
            where("submittedBy", "==", currentUser.uid)
        );

        const snapshot = await getDocs(projectsQuery);

        myProjects = snapshot.docs.map(document => ({
            id: document.id,
            ...document.data()
        }));

        updateStatistics();
        displayProjects();

    } catch (error) {
        console.error("Project loading error:", error);

        projectsGrid.innerHTML = `
            <p class="empty-message">
                Could not load your projects. Please refresh the page.
            </p>
        `;
    }
}


// ==========================================
// 8. DISPLAY PROJECTS
// ==========================================

function displayProjects() {
    if (!projectsGrid) return;

    let filteredProjects = [...myProjects];

    if (activeCategory !== "all") {
        filteredProjects = filteredProjects.filter(project =>
            project.category === activeCategory
        );
    }

    if (searchTerm) {
        filteredProjects = filteredProjects.filter(project => {
            const title = (project.title || "").toLowerCase();
            const description = (project.description || "").toLowerCase();

            return title.includes(searchTerm) ||
                   description.includes(searchTerm);
        });
    }

    if (filteredProjects.length === 0) {
        projectsGrid.innerHTML = `
            <div class="empty-message">
                <h3>No projects found</h3>
                <p>
                    Your submitted projects will appear here.
                    Try another search or category.
                </p>
            </div>
        `;

        return;
    }

    projectsGrid.innerHTML = filteredProjects.map(project => {
        const status = project.status || "pending";

        let statusLabel = "Pending Review";

        if (status === "approved") {
            statusLabel = "Approved";
        } else if (status === "rejected") {
            statusLabel = "Not Approved";
        }

        const safeLink = project.link &&
            /^https?:\/\//i.test(project.link)
            ? escapeHTML(project.link)
            : "";

        return `
            <article class="project-card">

                <div class="project-card-top">
                    <span class="project-category">
                        ${escapeHTML(project.category)}
                    </span>

                    <span class="project-status ${escapeHTML(status)}">
                        ${statusLabel}
                    </span>
                </div>

                <h3>${escapeHTML(project.title)}</h3>

                <p>${escapeHTML(project.description)}</p>

                ${
                    safeLink
                    ? `
                        <a
                            href="${safeLink}"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="project-link"
                        >
                            View Project ↗
                        </a>
                    `
                    : ""
                }

                <div class="project-card-footer">
                    <span>Submitted by you</span>
                </div>

            </article>
        `;
    }).join("");
}


// ==========================================
// 9. PROJECT STATISTICS
// ==========================================

function updateStatistics() {
    if (totalProjectsElement) {
        totalProjectsElement.textContent = myProjects.length;
    }

    if (myProjectsElement) {
        myProjectsElement.textContent = myProjects.length;
    }

    if (projectCategoriesElement) {
        const categories = new Set(
            myProjects.map(project => project.category)
        );

        projectCategoriesElement.textContent = categories.size;
    }
}


// ==========================================
// 10. SUBMIT PROJECT
// ==========================================

projectSubmissionForm?.addEventListener("submit", async event => {
    event.preventDefault();

    if (!currentUser) {
        alert("Please log in before submitting a project.");
        return;
    }

    const title = document.getElementById("projectTitle")?.value.trim();
    const category = document.getElementById("projectCategory")?.value;
    const description = document.getElementById("projectDescription")?.value.trim();
    const link = document.getElementById("projectLink")?.value.trim();

    if (!title || !category || !description) {
        alert("Please complete all required fields.");
        return;
    }

    if (title.length > 80 || description.length > 1000) {
        alert("Your project details are too long.");
        return;
    }

    if (link && !/^https?:\/\//i.test(link)) {
        alert("Please enter a valid link beginning with https:// or http://");
        return;
    }

    submitProjectButton.disabled = true;
    submitProjectButton.textContent = "Submitting...";

    try {
        const projectData = {
            title,
            category,
            description,
            submittedBy: currentUser.uid,
            submittedByName: currentMemberName,
            status: "pending",
            createdAt: serverTimestamp()
        };

        // Only save the link if the member entered one.
        if (link) {
            projectData.link = link;
        }

        await addDoc(
            collection(db, "projectSubmissions"),
            projectData
        );

        alert("Your project has been submitted successfully!");

        projectSubmissionForm.reset();

        projectForm?.classList.remove("active");

        await loadProjects();

    } catch (error) {
        console.error("Project submission error:", error);

        alert(
            "Your project could not be submitted. Please check your connection and try again."
        );

    } finally {
        submitProjectButton.disabled = false;
        submitProjectButton.textContent = "Submit Project";
    }
});


// ==========================================
// 11. CATEGORY FILTERS
// ==========================================

const categoryButtons = document.querySelectorAll("[data-filter]");

categoryButtons.forEach(button => {
    button.addEventListener("click", () => {

        categoryButtons.forEach(item => {
            item.classList.remove("active");
        });

        button.classList.add("active");

        activeCategory = button.dataset.filter;

        displayProjects();
    });
});


// ==========================================
// 12. PROJECT SEARCH
// ==========================================

projectSearch?.addEventListener("input", () => {
    searchTerm = projectSearch.value.toLowerCase().trim();

    displayProjects();
});


// ==========================================
// 13. AUTHENTICATION AND MEMBER ACCESS
// ==========================================

onAuthStateChanged(auth, async user => {

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    currentUser = user;

    try {

        // Check whether the account is a President.
        const { doc, getDoc } = await import(
            "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js"
        );

        const adminDocument = await getDoc(
            doc(db, "admins", user.uid)
        );

        if (adminDocument.exists()) {
            window.location.href = "admin.html";
            return;
        }

        // Check member account.
        const memberDocument = await getDoc(
            doc(db, "members", user.uid)
        );

        if (!memberDocument.exists()) {
            alert("Member account not found.");
            await signOut(auth);
            window.location.href = "login.html";
            return;
        }

        const memberData = memberDocument.data();

        if (memberData.status !== "approved") {
            alert("Your membership has not yet been approved.");
            await signOut(auth);
            window.location.href = "login.html";
            return;
        }

        currentMemberName = memberData.fullName || "Member";

        // Restore saved theme.
        if (localStorage.getItem("acc-member-theme") === "light") {
            document.body.classList.add("light-theme");
        }

        // Load the member's projects.
        await loadProjects();

        document.body.style.visibility = "visible";

    } catch (error) {
        console.error("Authentication error:", error);

        alert("Something went wrong while loading your account.");
        window.location.href = "login.html";
    }

});


// ==========================================
// ACC PROJECTS PAGE INITIALIZED
// ==========================================

console.log("ACC Projects page initialized!");