// ==========================================
// ASANTEMAN COMPUTING CLUB
// FIREBASE CONFIGURATION
// ==========================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-app.js";

import { getAuth } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import { getFirestore } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDnNlk6Q4MFYn_JwXX0VrvbBoJyvC1UJDY",
  authDomain: "asanteman-computing-club.firebaseapp.com",
  projectId: "asanteman-computing-club",
  storageBucket: "asanteman-computing-club.firebasestorage.app",
  messagingSenderId: "107372818920",
  appId: "1:107372818920:web:4e0e6c207e58fe04dff45d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
const auth = getAuth(app);
const db = getFirestore(app);

// Export services
export { app, auth, db };

console.log("ACC Firebase initialized!");