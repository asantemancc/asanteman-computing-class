// ==========================================
// ASANTEMAN COMPUTING CLUB - V2
// MAIN JAVASCRIPT
// ==========================================

document.addEventListener("DOMContentLoaded", function() {
  
  // ======================================
  // 1. LOADING SCREEN
  // ======================================
  
  const loader = document.getElementById("loader");
  
  function hideLoader() {
    if (loader) {
      loader.classList.add("hide");
    }
  }
  
  window.addEventListener("load", hideLoader);
  
  // Fallback in case the load event has already fired
  setTimeout(hideLoader, 1500);
  
  
  // ======================================
  // 2. MOBILE NAVIGATION
  // ======================================
  
  const menuToggle = document.getElementById("menuToggle");
  const navLinks = document.getElementById("navLinks");
  
  if (menuToggle && navLinks) {
    
    menuToggle.addEventListener("click", function() {
      
      navLinks.classList.toggle("open");
      
      const isOpen = navLinks.classList.contains("open");
      
      menuToggle.setAttribute("aria-expanded", isOpen);
      
      const icon = menuToggle.querySelector("i");
      
      if (icon) {
        icon.classList.toggle("fa-bars", !isOpen);
        icon.classList.toggle("fa-times", isOpen);
      }
      
    });
    
    // Close menu after clicking a navigation link
    navLinks.querySelectorAll("a").forEach(function(link) {
      
      link.addEventListener("click", function() {
        
        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        
        const icon = menuToggle.querySelector("i");
        
        if (icon) {
          icon.classList.remove("fa-times");
          icon.classList.add("fa-bars");
        }
        
      });
      
    });
    
    // Close menu when screen becomes larger
    window.addEventListener("resize", function() {
      
      if (window.innerWidth > 760) {
        
        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        
        const icon = menuToggle.querySelector("i");
        
        if (icon) {
          icon.classList.remove("fa-times");
          icon.classList.add("fa-bars");
        }
        
      }
      
    });
    
  }
  
  
  // ======================================
  // 3. AUTOMATIC FOOTER YEAR
  // ======================================
  
  const currentYear = document.getElementById("currentYear");
  
  if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
  }
  
  
  // ======================================
  // 4. BACK TO TOP BUTTON
  // ======================================
  
  const backToTop = document.getElementById("backToTop");
  
  if (backToTop) {
    
    window.addEventListener("scroll", function() {
      
      if (window.scrollY > 350) {
        backToTop.classList.add("show");
      } else {
        backToTop.classList.remove("show");
      }
      
    });
    
    backToTop.addEventListener("click", function() {
      
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
      
    });
    
  }
  
  
  // ======================================
  // 5. ACTIVE NAVIGATION LINK
  // ======================================
  
  const sections = document.querySelectorAll("main section[id]");
  const navigationLinks = document.querySelectorAll("#navLinks a");
  
  function updateActiveLink() {
    
    let currentSection = "";
    
    sections.forEach(function(section) {
      
      const sectionTop = section.offsetTop - 150;
      const sectionBottom = sectionTop + section.offsetHeight;
      
      if (
        window.scrollY >= sectionTop &&
        window.scrollY < sectionBottom
      ) {
        currentSection = section.getAttribute("id");
      }
      
    });
    
    navigationLinks.forEach(function(link) {
      
      link.classList.remove("active");
      
      if (link.getAttribute("href") === "#" + currentSection) {
        link.classList.add("active");
      }
      
    });
    
  }
  
  window.addEventListener("scroll", updateActiveLink);
  
  
  // ======================================
  // 6. INITIAL PAGE SETUP
  // ======================================
  
  updateActiveLink();
  
  console.log("ACC V2 JavaScript loaded successfully.");
  
});