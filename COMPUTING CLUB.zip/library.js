// ==========================================
// ASANTEMAN COMPUTING CLUB
// DIGITAL LIBRARY
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";


// ==========================================
// 1. SIDEBAR
// ==========================================

const sidebar = document.getElementById("memberSidebar");
const overlay = document.getElementById("sidebarOverlay");
const sidebarToggle = document.getElementById("sidebarToggle");

function openSidebar() {
    sidebar?.classList.add("active");
    overlay?.classList.add("active");
}

function closeSidebar() {
    sidebar?.classList.remove("active");
    overlay?.classList.remove("active");
}

sidebarToggle?.addEventListener("click", openSidebar);
overlay?.addEventListener("click", closeSidebar);


// ==========================================
// 2. LIBRARY RESOURCES
// ==========================================

const resources = [

    {
        id: 1,
        title: "Python Official Documentation",
        category: "Programming",
        icon: "🐍",
        description: "Learn Python programming using the official documentation and tutorials.",
        link: "https://docs.python.org/3/tutorial/"
    },

    {
        id: 2,
        title: "W3Schools Python Tutorial",
        category: "Programming",
        icon: "💻",
        description: "Beginner-friendly Python lessons with examples and exercises.",
        link: "https://www.w3schools.com/python/"
    },

    {
        id: 3,
        title: "HTML Learning Guide",
        category: "Web Development",
        icon: "🌐",
        description: "Learn how to structure websites using HTML.",
        link: "https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content"
    },

    {
        id: 4,
        title: "CSS Learning Guide",
        category: "Web Development",
        icon: "🎨",
        description: "Understand styling, layouts, colours and responsive website design.",
        link: "https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics"
    },

    {
        id: 5,
        title: "JavaScript Guide",
        category: "Programming",
        icon: "⚡",
        description: "Learn JavaScript fundamentals and how to make websites interactive.",
        link: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide"
    },

    {
        id: 6,
        title: "JavaScript Tutorial",
        category: "Web Development",
        icon: "🧩",
        description: "Explore JavaScript lessons, examples and practical exercises.",
        link: "https://www.w3schools.com/js/"
    },

    {
        id: 7,
        title: "Introduction to Artificial Intelligence",
        category: "Artificial Intelligence",
        icon: "🤖",
        description: "Explore artificial intelligence concepts and introductory learning materials.",
        link: "https://www.ibm.com/think/topics/artificial-intelligence"
    },

    {
        id: 8,
        title: "Machine Learning Basics",
        category: "Artificial Intelligence",
        icon: "🧠",
        description: "Understand how computers learn patterns from data.",
        link: "https://developers.google.com/machine-learning/intro-to-ml"
    },

    {
        id: 9,
        title: "Cybersecurity Fundamentals",
        category: "Cybersecurity",
        icon: "🔐",
        description: "Learn about online safety, security awareness and protecting information.",
        link: "https://www.cisa.gov/topics/cybersecurity-best-practices"
    },

    {
        id: 10,
        title: "OWASP Web Security",
        category: "Cybersecurity",
        icon: "🛡️",
        description: "Discover web application security principles and defensive practices.",
        link: "https://owasp.org/www-project-top-ten/"
    },

    {
        id: 11,
        title: "Computer Science Fundamentals",
        category: "Computer Science",
        icon: "🖥️",
        description: "Explore computing concepts, algorithms and computer science foundations.",
        link: "https://www.khanacademy.org/computing"
    },

    {
        id: 12,
        title: "CS50 Introduction to Computer Science",
        category: "Computer Science",
        icon: "🎓",
        description: "A free introductory computer science course from Harvard.",
        link: "https://cs50.harvard.edu/x/"
    },

    {
        id: 13,
        title: "SQL Tutorial",
        category: "Programming",
        icon: "🗄️",
        description: "Learn how to work with databases using SQL.",
        link: "https://www.w3schools.com/sql/"
    },

    {
        id: 14,
        title: "Git and GitHub Learning",
        category: "Programming",
        icon: "📂",
        description: "Learn version control and how developers manage projects.",
        link: "https://docs.github.com/en/get-started"
    },

    {
        id: 15,
        title: "Computer Networking Basics",
        category: "Computer Science",
        icon: "🌍",
        description: "Understand computer networks, internet communication and networking concepts.",
        link: "https://www.cloudflare.com/learning/network-layer/what-is-a-computer-network/"
    }

];


// ==========================================
// 3. ELEMENTS
// ==========================================

const libraryGrid = document.getElementById("libraryGrid");
const librarySearch = document.getElementById("librarySearch");

const categoryButtons = document.querySelectorAll("[data-category]");


// ==========================================
// 4. DISPLAY RESOURCES
// ==========================================

let activeCategory = "all";

function displayResources() {

    const searchTerm = librarySearch.value.trim().toLowerCase();

    const filteredResources = resources.filter(resource => {

        const matchesCategory =
            activeCategory === "all" ||
            resource.category === activeCategory;

        const matchesSearch =
            resource.title.toLowerCase().includes(searchTerm) ||
            resource.description.toLowerCase().includes(searchTerm) ||
            resource.category.toLowerCase().includes(searchTerm);

        return matchesCategory && matchesSearch;

    });

    libraryGrid.innerHTML = "";

    if (filteredResources.length === 0) {

        libraryGrid.innerHTML = `
            <div class="library-empty">
                <h3>No resources found</h3>
                <p>Try another search term or category.</p>
            </div>
        `;

        return;
    }

    filteredResources.forEach(resource => {

        const card = document.createElement("article");

        card.className = "resource-card";

        const icon = document.createElement("div");
        icon.className = "resource-icon";
        icon.textContent = resource.icon;

        const category = document.createElement("span");
        category.className = "resource-category";
        category.textContent = resource.category;

        const title = document.createElement("h3");
        title.textContent = resource.title;

        const description = document.createElement("p");
        description.textContent = resource.description;

        const link = document.createElement("a");
        link.href = resource.link;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.textContent = "Open Resource ↗";

        card.append(
            icon,
            category,
            title,
            description,
            link
        );

        libraryGrid.appendChild(card);

    });

}


// ==========================================
// 5. SEARCH
// ==========================================

librarySearch.addEventListener("input", displayResources);


// ==========================================
// 6. CATEGORY FILTERS
// ==========================================

categoryButtons.forEach(button => {

    button.addEventListener("click", () => {

        categoryButtons.forEach(item => {
            item.classList.remove("active");
        });

        button.classList.add("active");

        activeCategory = button.dataset.category;

        displayResources();

    });

});


// ==========================================
// 7. LOGOUT
// ==========================================

document.getElementById("libraryLogout")?.addEventListener("click", async () => {

    try {

        await signOut(auth);

        window.location.href = "login.html";

    } catch (error) {

        console.error("Logout error:", error);

        alert("Unable to log out. Please try again.");

    }

});


// ==========================================
// 8. AUTHENTICATION
// ==========================================

onAuthStateChanged(auth, async user => {

    if (!user) {

        window.location.href = "login.html";

        return;

    }

    try {

        const adminRef = await getDoc(doc(db, "admins", user.uid));

        if (adminRef.exists()) {

            window.location.href = "admin.html";

            return;

        }

        const memberRef = await getDoc(doc(db, "members", user.uid));

        if (!memberRef.exists()) {

            window.location.href = "login.html";

            return;

        }

        const member = memberRef.data();

        if (member.status !== "approved") {

            alert("Your membership is still awaiting approval.");

            await signOut(auth);

            window.location.href = "login.html";

            return;

        }

        document.getElementById("memberName").textContent =
            member.fullName || "Member";

        if (localStorage.getItem("acc-member-theme") === "light") {

            document.body.classList.add("light-theme");

        }

        displayResources();

        document.body.style.display = "block";

        console.log("ACC Digital Library initialized!");

    } catch (error) {

        console.error("Library authentication error:", error);

        alert("Unable to load the Digital Library. Please try again.");

        window.location.href = "login.html";

    }

});