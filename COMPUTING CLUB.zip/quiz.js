// ==========================================
// ASANTEMAN COMPUTING CLUB
// QUIZ ARENA
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";


// ==========================================
// 1. SIDEBAR NAVIGATION
// ==========================================

const sidebar = document.getElementById("memberSidebar");
const overlay = document.getElementById("sidebarOverlay");
const sidebarToggle = document.getElementById("sidebarToggle");

function openSidebar() {
    sidebar?.classList.add("active");
    overlay?.classList.add("active");
}

function closeSidebar() {
    sidebar?.classList.remove("active");
    overlay?.classList.remove("active");
}

sidebarToggle?.addEventListener("click", openSidebar);
overlay?.addEventListener("click", closeSidebar);

document.querySelectorAll(".member-nav-link").forEach(link => {
    link.addEventListener("click", closeSidebar);
});


// ==========================================
// 2. LOGOUT
// ==========================================

document.getElementById("quizLogout").addEventListener("click", async () => {

    if (!confirm("Are you sure you want to log out?")) return;

    try {
        await signOut(auth);
        window.location.href = "login.html";
    } catch (error) {
        console.error(error);
        alert("Unable to log out. Please try again.");
    }

});


// ==========================================
// 3. QUIZ QUESTIONS
// ==========================================

const quizzes = {

    python: {
        name: "Python Programming",
        questions: [

            {
                question: "Which function is used to display output in Python?",
                options: ["input()", "print()", "display()", "show()"],
                answer: 1,
                explanation: "The print() function displays information on the screen."
            },

            {
                question: "Which data type stores whole numbers?",
                options: ["str", "float", "int", "bool"],
                answer: 2,
                explanation: "The int data type stores whole numbers."
            },

            {
                question: "Which symbol is used for comments in Python?",
                options: ["//", "#", "/*", "--"],
                answer: 1,
                explanation: "Python uses the # symbol for single-line comments."
            },

            {
                question: "Which keyword is used to define a function?",
                options: ["function", "define", "func", "def"],
                answer: 3,
                explanation: "The def keyword is used to define a function."
            },

            {
                question: "What is the result of 5 + 3 * 2?",
                options: ["16", "11", "13", "10"],
                answer: 1,
                explanation: "Multiplication comes before addition, so 5 + 6 = 11."
            }

        ]
    },


    web: {
        name: "Web Development",
        questions: [

            {
                question: "What does HTML stand for?",
                options: [
                    "HyperText Markup Language",
                    "HighText Machine Language",
                    "Hyper Transfer Main Language",
                    "Home Tool Markup Language"
                ],
                answer: 0,
                explanation: "HTML means HyperText Markup Language."
            },

            {
                question: "Which language is used to style web pages?",
                options: ["Python", "HTML", "CSS", "SQL"],
                answer: 2,
                explanation: "CSS controls the appearance and layout of web pages."
            },

            {
                question: "Which HTML element creates a hyperlink?",
                options: ["<link>", "<a>", "<href>", "<url>"],
                answer: 1,
                explanation: "The <a> element creates a hyperlink."
            },

            {
                question: "Which language adds interactivity to websites?",
                options: ["CSS", "HTML", "SQL", "JavaScript"],
                answer: 3,
                explanation: "JavaScript is commonly used to make websites interactive."
            },

            {
                question: "Which HTML element displays the largest default heading?",
                options: ["<h6>", "<head>", "<h1>", "<heading>"],
                answer: 2,
                explanation: "The <h1> element represents the highest-level heading."
            }

        ]
    },


    ai: {
        name: "Artificial Intelligence",
        questions: [

            {
                question: "What does AI stand for?",
                options: [
                    "Automated Internet",
                    "Artificial Intelligence",
                    "Advanced Information",
                    "Automatic Integration"
                ],
                answer: 1,
                explanation: "AI means Artificial Intelligence."
            },

            {
                question: "Which is a branch of Artificial Intelligence?",
                options: [
                    "Machine Learning",
                    "Word Processing",
                    "File Management",
                    "Data Entry"
                ],
                answer: 0,
                explanation: "Machine Learning is a branch of Artificial Intelligence."
            },

            {
                question: "What does a machine learning system learn from?",
                options: ["Electricity", "A keyboard", "Data", "A monitor"],
                answer: 2,
                explanation: "Machine learning systems identify patterns using data."
            },

            {
                question: "Which is an example of an AI application?",
                options: [
                    "A wooden desk",
                    "A basic light switch",
                    "A paper notebook",
                    "A voice assistant"
                ],
                answer: 3,
                explanation: "Voice assistants use AI technologies to interpret requests."
            },

            {
                question: "Which is an important responsible AI principle?",
                options: ["Privacy", "Secrecy at all costs", "Ignoring errors", "Removing human oversight"],
                answer: 0,
                explanation: "Protecting privacy is an important responsible AI principle."
            }

        ]
    },


    cybersecurity: {
        name: "Cybersecurity",
        questions: [

            {
                question: "What is cybersecurity?",
                options: [
                    "Designing posters",
                    "Protecting digital systems and information",
                    "Writing stories",
                    "Repairing furniture"
                ],
                answer: 1,
                explanation: "Cybersecurity protects computers, networks and information."
            },

            {
                question: "What is phishing?",
                options: [
                    "A programming language",
                    "A type of keyboard",
                    "A deceptive attempt to obtain sensitive information",
                    "A computer screen"
                ],
                answer: 2,
                explanation: "Phishing uses deceptive messages or websites to trick people."
            },

            {
                question: "Which is a good password practice?",
                options: [
                    "Using a unique, long password",
                    "Sharing your password",
                    "Using your name only",
                    "Using the same password everywhere"
                ],
                answer: 0,
                explanation: "Long, unique passwords help protect accounts."
            },

            {
                question: "What does MFA stand for?",
                options: [
                    "Main File Access",
                    "Multiple Folder Application",
                    "Managed Firewall Access",
                    "Multi-Factor Authentication"
                ],
                answer: 3,
                explanation: "MFA means Multi-Factor Authentication."
            },

            {
                question: "What is malware?",
                options: [
                    "A web browser",
                    "Harmful software",
                    "A programming course",
                    "A storage device"
                ],
                answer: 1,
                explanation: "Malware is software designed to cause harm or unwanted activity."
            }

        ]
    },


    database: {
        name: "Database Systems",
        questions: [

            {
                question: "What is a database?",
                options: [
                    "An organised collection of data",
                    "A computer monitor",
                    "A programming keyboard",
                    "A network cable"
                ],
                answer: 0,
                explanation: "A database stores organised information."
            },

            {
                question: "What does SQL stand for?",
                options: [
                    "Simple Question Language",
                    "System Query Link",
                    "Structured Query Language",
                    "Standard Quick Language"
                ],
                answer: 2,
                explanation: "SQL means Structured Query Language."
            },

            {
                question: "In a database table, what is a row commonly called?",
                options: ["Field", "Record", "Column", "Formula"],
                answer: 1,
                explanation: "A row contains a record."
            },

            {
                question: "Which SQL command retrieves data?",
                options: ["DELETE", "UPDATE", "INSERT", "SELECT"],
                answer: 3,
                explanation: "SELECT retrieves information from a database."
            },

            {
                question: "What is a primary key used for?",
                options: [
                    "Uniquely identifying records",
                    "Changing font size",
                    "Displaying images",
                    "Connecting a monitor"
                ],
                answer: 0,
                explanation: "A primary key uniquely identifies each record in a table."
            }

        ]
    },


    computer: {
        name: "Computer Fundamentals",
        questions: [

            {
                question: "Which component is known as the brain of the computer?",
                options: ["Monitor", "Keyboard", "CPU", "Mouse"],
                answer: 2,
                explanation: "The CPU processes instructions and performs calculations."
            },

            {
                question: "Which of these is an input device?",
                options: ["Monitor", "Keyboard", "Speaker", "Printer"],
                answer: 1,
                explanation: "A keyboard sends data into a computer."
            },

            {
                question: "What does RAM stand for?",
                options: [
                    "Read Access Memory",
                    "Run Application Memory",
                    "Random Active Machine",
                    "Random Access Memory"
                ],
                answer: 3,
                explanation: "RAM means Random Access Memory."
            },

            {
                question: "Which is an example of system software?",
                options: [
                    "Operating system",
                    "Presentation slide",
                    "Digital photograph",
                    "Text document"
                ],
                answer: 0,
                explanation: "An operating system is system software."
            },

            {
                question: "What does LAN stand for?",
                options: [
                    "Large Access Network",
                    "Local Area Network",
                    "Linked Application Node",
                    "Long Access Number"
                ],
                answer: 1,
                explanation: "LAN means Local Area Network."
            }

        ]
    }

};


// ==========================================
// 4. QUIZ ELEMENTS
// ==========================================

const categories = document.getElementById("quizCategories");
const quizArea = document.getElementById("quizArea");
const quizResult = document.getElementById("quizResult");

const categoryName = document.getElementById("quizCategoryName");
const questionCounter = document.getElementById("questionCounter");
const questionText = document.getElementById("questionText");
const answerOptions = document.getElementById("answerOptions");
const quizFeedback = document.getElementById("quizFeedback");
const progressBar = document.getElementById("quizProgressBar");

const nextButton = document.getElementById("nextQuestion");
const quitButton = document.getElementById("quitQuiz");

let currentCategory = null;
let currentQuestion = 0;
let score = 0;
let answered = false;
let currentUserId = null;


// ==========================================
// 5. USER STATISTICS
// ==========================================

let quizStats = {
    attempts: 0,
    correct: 0,
    best: 0
};

function getStatsKey() {
    return `accQuizStats_${currentUserId}`;
}

function loadStats() {

    try {
        const saved = localStorage.getItem(getStatsKey());

        if (saved) {
            const parsed = JSON.parse(saved);

            quizStats = {
                attempts: Number(parsed.attempts) || 0,
                correct: Number(parsed.correct) || 0,
                best: Number(parsed.best) || 0
            };
        }
    } catch (error) {
        console.error("Could not load quiz statistics:", error);
    }

    updateStatsDisplay();
}

function saveStats() {

    localStorage.setItem(
        getStatsKey(),
        JSON.stringify(quizStats)
    );

    updateStatsDisplay();
}

function updateStatsDisplay() {

    document.getElementById("totalAttempts").textContent =
        quizStats.attempts;

    document.getElementById("totalCorrect").textContent =
        quizStats.correct;

    document.getElementById("bestScore").textContent =
        quizStats.best + "%";
}


// ==========================================
// 6. START QUIZ
// ==========================================

window.startQuiz = function(category) {

    if (!quizzes[category]) return;

    currentCategory = category;
    currentQuestion = 0;
    score = 0;
    answered = false;

    categories.style.display = "none";
    quizResult.classList.remove("active");
    quizArea.classList.add("active");

    categoryName.textContent = quizzes[category].name;

    showQuestion();

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

};


// ==========================================
// 7. DISPLAY QUESTION
// ==========================================

function showQuestion() {

    const quiz = quizzes[currentCategory];
    const question = quiz.questions[currentQuestion];

    answered = false;

    questionCounter.textContent =
        `Question ${currentQuestion + 1} of ${quiz.questions.length}`;

    questionText.textContent = question.question;

    progressBar.style.width =
        `${((currentQuestion + 1) / quiz.questions.length) * 100}%`;

    answerOptions.innerHTML = "";

    quizFeedback.textContent = "";
    quizFeedback.classList.remove("show");

    question.options.forEach((option, index) => {

        const button = document.createElement("button");

        button.className = "answer-option";
        button.textContent = option;

        button.addEventListener("click", () => {
            selectAnswer(index, button);
        });

        answerOptions.appendChild(button);

    });

    nextButton.disabled = true;
    nextButton.textContent =
        currentQuestion === quiz.questions.length - 1
            ? "View Results"
            : "Next Question";

}


// ==========================================
// 8. CHECK ANSWER
// ==========================================

function selectAnswer(selectedIndex, selectedButton) {

    if (answered) return;

    answered = true;

    const question =
        quizzes[currentCategory].questions[currentQuestion];

    const buttons =
        answerOptions.querySelectorAll(".answer-option");

    buttons.forEach(button => {
        button.disabled = true;
    });

    if (selectedIndex === question.answer) {

        score++;

        selectedButton.classList.add("correct");

        quizFeedback.textContent =
            "Correct! " + question.explanation;

        quizFeedback.style.background = "#14532d";
        quizFeedback.style.color = "#dcfce7";

    } else {

        selectedButton.classList.add("wrong");

        buttons[question.answer].classList.add("correct");

        quizFeedback.textContent =
            "Not quite. " + question.explanation;

        quizFeedback.style.background = "#7f1d1d";
        quizFeedback.style.color = "#fee2e2";

    }

    quizFeedback.classList.add("show");

    nextButton.disabled = false;

}


// ==========================================
// 9. NEXT QUESTION
// ==========================================

nextButton.addEventListener("click", () => {

    if (!answered) return;

    const quiz = quizzes[currentCategory];

    if (currentQuestion < quiz.questions.length - 1) {

        currentQuestion++;
        showQuestion();

    } else {

        finishQuiz();

    }

});


// ==========================================
// 10. FINISH QUIZ
// ==========================================

function finishQuiz() {

    const quiz = quizzes[currentCategory];

    const percentage = Math.round(
        (score / quiz.questions.length) * 100
    );

    quizStats.attempts++;
    quizStats.correct += score;

    if (percentage > quizStats.best) {
        quizStats.best = percentage;
    }

    saveStats();

    quizArea.classList.remove("active");
    quizResult.classList.add("active");

    document.getElementById("resultScore").textContent =
        `${score}/${quiz.questions.length} (${percentage}%)`;

    let message;

    if (percentage === 100) {
        message = "Outstanding!";
    } else if (percentage >= 80) {
        message = "Excellent work!";
    } else if (percentage >= 60) {
        message = "Good effort!";
    } else if (percentage >= 40) {
        message = "Keep practising!";
    } else {
        message = "Keep learning and try again!";
    }

    document.getElementById("resultMessage").textContent = message;

    document.getElementById("resultDescription").textContent =
        `You answered ${score} out of ${quiz.questions.length} questions correctly in ${quiz.name}.`;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


// ==========================================
// 11. EXIT QUIZ
// ==========================================

quitButton.addEventListener("click", () => {

    if (!confirm("Are you sure you want to exit this quiz? Your current attempt will not be counted.")) {
        return;
    }

    quizArea.classList.remove("active");
    quizResult.classList.remove("active");

    categories.style.display = "block";

    currentCategory = null;

});


// ==========================================
// 12. RETRY QUIZ
// ==========================================

document.getElementById("retryQuiz").addEventListener("click", () => {

    if (currentCategory) {
        window.startQuiz(currentCategory);
    }

});


// ==========================================
// 13. RETURN TO CATEGORIES
// ==========================================

document.getElementById("returnCategories").addEventListener("click", () => {

    quizResult.classList.remove("active");
    categories.style.display = "block";

    currentCategory = null;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

});


// ==========================================
// 14. CURRENT YEAR
// ==========================================

document.getElementById("quizYear").textContent =
    new Date().getFullYear();


// ==========================================
// 15. FIREBASE AUTHENTICATION
// ==========================================

document.body.style.display = "none";

onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    try {

        // Check administrator account
        const adminRef = doc(db, "admins", user.uid);
        const adminSnap = await getDoc(adminRef);

        if (adminSnap.exists()) {
            window.location.href = "admin.html";
            return;
        }

        // Check member account
        const memberRef = doc(db, "members", user.uid);
        const memberSnap = await getDoc(memberRef);

        if (!memberSnap.exists()) {
            await signOut(auth);
            window.location.href = "login.html";
            return;
        }

        const memberData = memberSnap.data();

        if (memberData.status !== "approved") {

            await signOut(auth);

            alert("Your membership has not yet been approved.");

            window.location.href = "login.html";
            return;

        }

        currentUserId = user.uid;

        const nameElement =
            document.getElementById("sidebarMemberName");

        if (nameElement) {
            nameElement.textContent =
                memberData.fullName || "ACC Member";
        }

        // Restore saved theme
        const savedTheme =
            localStorage.getItem("acc-member-theme");

        if (savedTheme === "light") {
            document.body.classList.add("light-theme");
        }

        loadStats();

        document.body.style.display = "";

    } catch (error) {

        console.error("Quiz authentication error:", error);

        alert("Unable to verify your account. Please log in again.");

        await signOut(auth);

        window.location.href = "login.html";

    }

});

console.log("ACC Quiz Arena loaded successfully.");