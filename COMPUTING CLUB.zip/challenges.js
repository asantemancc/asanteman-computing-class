// ==========================================
// ASANTEMAN COMPUTING CLUB
// CODING CHALLENGES
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";


// ==========================================
// 1. SIDEBAR
// ==========================================

const sidebar = document.getElementById("memberSidebar");
const overlay = document.getElementById("sidebarOverlay");
const sidebarToggle = document.getElementById("sidebarToggle");

function openSidebar() {
    sidebar?.classList.add("active");
    overlay?.classList.add("active");
}

function closeSidebar() {
    sidebar?.classList.remove("active");
    overlay?.classList.remove("active");
}

sidebarToggle?.addEventListener("click", openSidebar);
overlay?.addEventListener("click", closeSidebar);


// ==========================================
// 2. CHALLENGE DATABASE
// ==========================================

const challenges = [

    {
        id: 1,
        title: "Hello, World!",
        category: "Python",
        difficulty: "Beginner",
        description: "Write a Python program that displays the message Hello, World! on the screen.",
        starter: "# Write your code below\n",
        hints: "Use Python's print() function.",
        keywords: ["print", "hello"]
    },

    {
        id: 2,
        title: "Add Two Numbers",
        category: "Python",
        difficulty: "Beginner",
        description: "Create two variables containing numbers. Add them together and display the result.",
        starter: "num1 = 10\nnum2 = 20\n\n# Complete your program\n",
        hints: "Use the + operator and print() to display the answer.",
        keywords: ["+", "print"]
    },

    {
        id: 3,
        title: "Even or Odd",
        category: "Python",
        difficulty: "Intermediate",
        description: "Write a program that checks whether a number is even or odd.",
        starter: "number = 8\n\n# Write your condition here\n",
        hints: "Use the modulo operator (%) and an if/else statement.",
        keywords: ["if", "else", "%"]
    },

    {
        id: 4,
        title: "Create a Heading",
        category: "HTML",
        difficulty: "Beginner",
        description: "Write an HTML heading that displays the text Welcome to ACC.",
        starter: "<!-- Write your HTML here -->\n",
        hints: "Use an h1 opening tag and closing tag.",
        keywords: ["<h1", "</h1>", "welcome"]
    },

    {
        id: 5,
        title: "Create a Paragraph",
        category: "HTML",
        difficulty: "Beginner",
        description: "Create an HTML paragraph containing the text I love Computing.",
        starter: "<!-- Write your HTML here -->\n",
        hints: "Use the p element.",
        keywords: ["<p", "</p>", "computing"]
    },

    {
        id: 6,
        title: "Style a Heading",
        category: "CSS",
        difficulty: "Beginner",
        description: "Write a CSS rule that changes all h1 headings to green.",
        starter: "/* Write your CSS here */\n",
        hints: "Use the h1 selector and the color property.",
        keywords: ["h1", "color", "green"]
    },

    {
        id: 7,
        title: "Round Corners",
        category: "CSS",
        difficulty: "Intermediate",
        description: "Write a CSS rule that gives all buttons rounded corners using a 10px border radius.",
        starter: "/* Write your CSS here */\n",
        hints: "Use the button selector and border-radius property.",
        keywords: ["button", "border-radius", "10px"]
    },

    {
        id: 8,
        title: "Display a Message",
        category: "JavaScript",
        difficulty: "Beginner",
        description: "Write JavaScript code that displays Hello ACC! in the browser console.",
        starter: "// Write your JavaScript here\n",
        hints: "Use console.log().",
        keywords: ["console.log", "hello"]
    },

    {
        id: 9,
        title: "Calculate a Sum",
        category: "JavaScript",
        difficulty: "Intermediate",
        description: "Create two variables, add their values and display the result using console.log().",
        starter: "let a = 5;\nlet b = 10;\n\n// Complete your code\n",
        hints: "Use the + operator and console.log().",
        keywords: ["+", "console.log"]
    },

    {
        id: 10,
        title: "Simple Function",
        category: "Python",
        difficulty: "Intermediate",
        description: "Create a Python function named greet that displays Welcome to ACC! when called.",
        starter: "# Write your function here\n",
        hints: "Use def to define a function and call it afterwards.",
        keywords: ["def", "greet", "print"]
    }

];


// ==========================================
// 3. ELEMENTS
// ==========================================

const challengeGrid = document.getElementById("challengeGrid");
const completedCount = document.getElementById("completedCount");
const availableCount = document.getElementById("availableCount");
const completionRate = document.getElementById("completionRate");

const workspace = document.getElementById("challengeWorkspace");
const workspaceTitle = document.getElementById("workspaceTitle");
const workspaceDifficulty = document.getElementById("workspaceDifficulty");
const workspaceDescription = document.getElementById("workspaceDescription");

const codeEditor = document.getElementById("codeEditor");
const challengeFeedback = document.getElementById("challengeFeedback");

const checkButton = document.getElementById("checkChallenge");
const closeButton = document.getElementById("closeWorkspace");

const filterButtons = document.querySelectorAll("[data-filter]");


// ==========================================
// 4. USER PROGRESS
// ==========================================

let currentUserId = null;
let currentChallenge = null;

function progressKey() {
    return `accChallenges_${currentUserId}`;
}

function getProgress() {
    try {
        return JSON.parse(localStorage.getItem(progressKey())) || [];
    } catch (error) {
        return [];
    }
}

function saveProgress(progress) {
    localStorage.setItem(progressKey(), JSON.stringify(progress));
}

function updateStats() {
    const completed = getProgress().length;

    completedCount.textContent = completed;
    availableCount.textContent = challenges.length;

    completionRate.textContent =
        Math.round((completed / challenges.length) * 100) + "%";
}


// ==========================================
// 5. DISPLAY CHALLENGES
// ==========================================

function displayChallenges(category = "all") {

    challengeGrid.innerHTML = "";

    const progress = getProgress();

    const filtered = category === "all"
        ? challenges
        : challenges.filter(challenge => challenge.category === category);

    if (filtered.length === 0) {
        challengeGrid.innerHTML =
            `<div class="challenge-empty">No challenges found.</div>`;
        return;
    }

    filtered.forEach(challenge => {

        const completed = progress.includes(challenge.id);

        const card = document.createElement("div");
        card.className = "challenge-card";

        const icon = {
            Python: "🐍",
            HTML: "🌐",
            CSS: "🎨",
            JavaScript: "⚡"
        }[challenge.category];

        card.innerHTML = `
            <div class="challenge-icon">${icon}</div>

            <h3>${challenge.title}</h3>

            <p>${challenge.description}</p>

            <div class="challenge-meta">
                <span>${challenge.category}</span>
                <span class="difficulty">${challenge.difficulty}</span>
            </div>

            <button type="button">
                ${completed ? "Practice Again ✓" : "Start Challenge"}
            </button>
        `;

        card.querySelector("button").addEventListener("click", () => {
            openChallenge(challenge.id);
        });

        challengeGrid.appendChild(card);

    });

}


// ==========================================
// 6. OPEN CHALLENGE
// ==========================================

function openChallenge(id) {

    currentChallenge = challenges.find(item => item.id === id);

    if (!currentChallenge) return;

    workspaceTitle.textContent = currentChallenge.title;
    workspaceDifficulty.textContent = currentChallenge.difficulty;
    workspaceDescription.textContent = currentChallenge.description;

    codeEditor.value = currentChallenge.starter;

    challengeFeedback.style.display = "none";
    challengeFeedback.textContent = "";

    workspace.style.display = "block";

    workspace.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}


// ==========================================
// 7. CHECK SOLUTION
// ==========================================

checkButton.addEventListener("click", () => {

    if (!currentChallenge) return;

    const code = codeEditor.value.toLowerCase();

    const completed = currentChallenge.keywords.every(keyword =>
        code.includes(keyword.toLowerCase())
    );

    challengeFeedback.style.display = "block";

    if (completed) {

        challengeFeedback.style.background = "rgba(22,163,106,.15)";
        challengeFeedback.style.color = "#35d996";

        challengeFeedback.textContent =
            "Great work! Your code contains the expected elements. Remember, this is a basic keyword check, not a full code execution or correctness test.";

        const progress = getProgress();

        if (!progress.includes(currentChallenge.id)) {
            progress.push(currentChallenge.id);
            saveProgress(progress);
        }

        updateStats();
        displayChallenges(getActiveFilter());

    } else {

        challengeFeedback.style.background = "rgba(220,70,70,.12)";
        challengeFeedback.style.color = "#ff8585";

        challengeFeedback.textContent =
            "Not quite yet. Review the instructions and hint, then try again. Your progress has not been marked complete.";

    }

});


// ==========================================
// 8. FILTER CHALLENGES
// ==========================================

function getActiveFilter() {
    return document.querySelector("[data-filter].active")?.dataset.filter || "all";
}

filterButtons.forEach(button => {

    button.addEventListener("click", () => {

        filterButtons.forEach(item => item.classList.remove("active"));

        button.classList.add("active");

        displayChallenges(button.dataset.filter);

    });

});


// ==========================================
// 9. CLOSE WORKSPACE
// ==========================================

closeButton.addEventListener("click", () => {

    workspace.style.display = "none";
    currentChallenge = null;

});


// ==========================================
// 10. LOGOUT
// ==========================================

document.getElementById("challengeLogout")?.addEventListener("click", async () => {

    try {
        await signOut(auth);
        window.location.href = "login.html";
    } catch (error) {
        alert("Unable to log out. Please try again.");
    }

});


// ==========================================
// 11. AUTHENTICATION
// ==========================================

onAuthStateChanged(auth, async user => {

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    try {

        const adminRef = await getDoc(doc(db, "admins", user.uid));

        if (adminRef.exists()) {
            window.location.href = "admin.html";
            return;
        }

        const memberRef = await getDoc(doc(db, "members", user.uid));

        if (!memberRef.exists()) {
            window.location.href = "login.html";
            return;
        }

        const member = memberRef.data();

        if (member.status !== "approved") {
            alert("Your membership is still awaiting approval.");
            await signOut(auth);
            window.location.href = "login.html";
            return;
        }

        currentUserId = user.uid;

        document.getElementById("memberName").textContent =
            member.fullName || "Member";

        if (localStorage.getItem("acc-member-theme") === "light") {
            document.body.classList.add("light-theme");
        }

        updateStats();
        displayChallenges();

        document.body.style.display = "block";

        console.log("ACC Coding Challenges initialized!");

    } catch (error) {

        console.error("Challenge authentication error:", error);

        alert("Unable to load Coding Challenges. Please try again.");

        window.location.href = "login.html";

    }

});