import { auth, db } from "./firebase.js";

import {
  signInWithEmailAndPassword,
  signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
  doc,
  getDoc
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";

const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");

loginForm.addEventListener("submit", async function(event) {
  event.preventDefault();
  
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  
  const button = loginForm.querySelector("button[type='submit']");
  
  button.disabled = true;
  button.textContent = "Signing in...";
  
  try {
    const result = await signInWithEmailAndPassword(
      auth,
      email,
      password
    );
    
    const user = result.user;
    
    
    // Check member account
    const memberRef = doc(db, "members", user.uid);
    const memberSnapshot = await getDoc(memberRef);
    
    if (!memberSnapshot.exists()) {
      await signOut(auth);
      showMessage("Member account not found.", "error");
      return;
    }
    
    const member = memberSnapshot.data();
    
    if (member.status !== "approved") {
      await signOut(auth);
      
      showMessage(
        "Your membership is awaiting President approval.",
        "error"
      );
      
      return;
    }
    
    window.location.href = "member.html";
    
  } catch (error) {
    console.error("Login error:", error);
    
    showMessage(
      "Login failed: " + error.message,
      "error"
    );
    
  } finally {
    button.disabled = false;
    button.textContent = "Login";
  }
});

function showMessage(message, type) {
  loginMessage.textContent = message;
  loginMessage.className = "form-message " + type;
}