// ==========================================
// ACC V2 - STUDENT REGISTRATION
// ==========================================

import { auth, db } from "./firebase.js";

import {
  createUserWithEmailAndPassword,
  updateProfile
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";
import {
  doc,
  setDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";

const registerForm = document.getElementById("registerForm");
const registerMessage = document.getElementById("registerMessage");

registerForm.addEventListener("submit", async function(event) {
  event.preventDefault();
  
  const fullName = document.getElementById("fullName").value.trim();
  const email = document.getElementById("email").value.trim();
  const studentClass = document.getElementById("studentClass").value;
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  
  if (!fullName || !email || !studentClass || !password || !confirmPassword) {
    showMessage("Please complete all fields.", "error");
    return;
  }
  
  if (password !== confirmPassword) {
    showMessage("Your passwords do not match.", "error");
    return;
  }
  
  if (password.length < 6) {
    showMessage("Your password must contain at least 6 characters.", "error");
    return;
  }
  
  const submitButton = registerForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  submitButton.textContent = "Creating account...";
  
  try {
    // Create Firebase account
    const userCredential = await createUserWithEmailAndPassword(
      auth,
      email,
      password
    );
    
    const user = userCredential.user;
    
    // Save student's display name
    await updateProfile(user, {
      displayName: fullName
    });
    // Send verification email
console.log("Verification email sent successfully!");
    // Save membership application
    await setDoc(doc(db, "members", user.uid), {
      uid: user.uid,
      fullName: fullName,
      email: email,
      studentClass: studentClass,
      role: "member",
      status: "pending",
      createdAt: serverTimestamp()
    });
    
    showMessage(
     "Registration successful! A verification link has been sent to your email. Verify your email, then wait for President approval."
    );
    
    registerForm.reset();
    
  } catch (error) {
    console.error("Registration error:", error);
    
    if (error.code === "auth/email-already-in-use") {
      showMessage("This email already has an account.", "error");
    } else if (error.code === "auth/invalid-email") {
      showMessage("Please enter a valid email address.", "error");
    } else if (error.code === "auth/weak-password") {
      showMessage("Please choose a stronger password.", "error");
    } else {
      showMessage(
        "Registration failed: " + error.message,
        "error"
      );
    }
    
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Create Account";
  }
});

function showMessage(message, type) {
  registerMessage.textContent = message;
  registerMessage.className = "form-message " + type;
}