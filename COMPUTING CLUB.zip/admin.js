// ==========================================
// ASANTEMAN COMPUTING CLUB
// PRESIDENT ADMIN SYSTEM
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
    doc,
    getDoc,
    collection,
    getDocs,
    updateDoc,
    addDoc,
    deleteDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";


// ==========================================
// ELEMENTS
// ==========================================

const sidebar = document.getElementById("adminSidebar");
const overlay = document.getElementById("adminOverlay");
const toggle = document.getElementById("adminSidebarToggle");

const logoutButton = document.getElementById("adminLogout");
const settingsLogout = document.getElementById("settingsAdminLogout");

const applicationsList = document.getElementById("applicationsList");
const membersList = document.getElementById("membersList");

const announcementForm = document.getElementById("announcementForm");
const announcementList = document.getElementById("adminAnnouncementsList");

const eventForm = document.getElementById("eventForm");
const eventList = document.getElementById("adminEventsList");
// PROJECT REVIEW ELEMENTS
const adminProjectsList = document.getElementById("adminProjectsList");
const adminTotalProjects = document.getElementById("adminTotalProjects");
const adminPendingProjects = document.getElementById("adminPendingProjects");
const adminApprovedProjects = document.getElementById("adminApprovedProjects");

let currentPresident = null;


// ==========================================
// SIDEBAR
// ==========================================

function closeSidebar() {
    if (sidebar) sidebar.classList.remove("open");
    if (overlay) overlay.classList.remove("show");
}

if (toggle) {
    toggle.addEventListener("click", () => {
        sidebar.classList.toggle("open");
        overlay.classList.toggle("show");
    });
}

if (overlay) {
    overlay.addEventListener("click", closeSidebar);
}


// ==========================================
// NAVIGATION
// ==========================================

const adminLinks = document.querySelectorAll(".sidebar-link");
const adminSections = document.querySelectorAll(
    ".admin-main .dashboard-section"
);

adminLinks.forEach(link => {

    link.addEventListener("click", event => {

        event.preventDefault();

        const target = link.getAttribute("href").substring(1);

        adminLinks.forEach(item =>
            item.classList.remove("active")
        );

        adminSections.forEach(section =>
            section.classList.remove("active")
        );

        link.classList.add("active");

        const targetSection = document.getElementById(target);

        if (targetSection) {
            targetSection.classList.add("active");
        }

        closeSidebar();

    });

});


// ==========================================
// PRESIDENT AUTHENTICATION
// ==========================================

onAuthStateChanged(auth, async user => {

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    try {

        const adminRef = doc(db, "admins", user.uid);
        const adminSnapshot = await getDoc(adminRef);

        if (!adminSnapshot.exists()) {

            alert("Access denied. President privileges required.");

            await signOut(auth);

            window.location.href = "login.html";

            return;
        }

        currentPresident = user;

        const presidentName = user.displayName || "President";
        const presidentEmail = user.email || "Email unavailable";

        document.getElementById("adminName").textContent =
            presidentName;

        document.getElementById("adminEmail").textContent =
            presidentEmail;

        const settingsName = document.getElementById("settingsAdminName");
        const settingsEmail = document.getElementById("settingsAdminEmail");

        if (settingsName) settingsName.textContent = presidentName;
        if (settingsEmail) settingsEmail.textContent = presidentEmail;

        document.body.style.visibility = "visible";

        await loadDashboard();
await loadAnnouncements();
await loadEvents();
await loadProjects();

    } catch (error) {

        console.error("Admin verification error:", error);

        alert("Unable to verify your administrator account.");

        await signOut(auth);

        window.location.href = "login.html";

    }

});


// ==========================================
// LOAD DASHBOARD
// ==========================================

async function loadDashboard() {

    try {

        const snapshot = await getDocs(collection(db, "members"));

        let total = 0;
        let pending = 0;
        let approved = 0;

        const applications = [];
        const members = [];

        snapshot.forEach(documentSnapshot => {

            const member = documentSnapshot.data();

            total++;

            if (member.status === "pending") {

                pending++;

                applications.push({
                    id: documentSnapshot.id,
                    ...member
                });

            }

            if (member.status === "approved") {

                approved++;

                members.push({
                    id: documentSnapshot.id,
                    ...member
                });

            }

        });

        document.getElementById("totalMembers").textContent = total;
        document.getElementById("pendingMembers").textContent = pending;
        document.getElementById("approvedMembers").textContent = approved;

        displayApplications(applications);
        displayMembers(members);

    } catch (error) {

        console.error("Dashboard loading error:", error);

        applicationsList.textContent =
            "Unable to load applications.";

        membersList.textContent =
            "Unable to load members.";

    }

}


// ==========================================
// DISPLAY APPLICATIONS
// ==========================================

function displayApplications(applications) {

    applicationsList.innerHTML = "";

    if (applications.length === 0) {

        applicationsList.textContent =
            "No pending applications.";

        return;
    }

    applications.forEach(member => {

        const card = document.createElement("div");
        card.className = "admin-member-card";

        const name = document.createElement("h3");
        name.textContent = member.fullName || "Unnamed student";

        const email = document.createElement("p");
        email.textContent = member.email || "";

        const studentClass = document.createElement("p");
        studentClass.textContent = member.studentClass || "";

        const approveButton = document.createElement("button");
        approveButton.textContent = "Approve";
        approveButton.className = "approve-button";

        approveButton.addEventListener("click", () => {
            updateMemberStatus(member.id, "approved");
        });

        const rejectButton = document.createElement("button");
        rejectButton.textContent = "Reject";
        rejectButton.className = "reject-button";

        rejectButton.addEventListener("click", () => {
            updateMemberStatus(member.id, "rejected");
        });

        card.append(
            name,
            email,
            studentClass,
            approveButton,
            rejectButton
        );

        applicationsList.appendChild(card);

    });

}


// ==========================================
// DISPLAY APPROVED MEMBERS
// ==========================================

function displayMembers(members) {

    membersList.innerHTML = "";

    if (members.length === 0) {

        membersList.textContent =
            "No approved members yet.";

        return;
    }

    members.forEach(member => {

        const card = document.createElement("div");
        card.className = "admin-member-card";

        const name = document.createElement("h3");
        name.textContent = member.fullName || "Unnamed student";

        const email = document.createElement("p");
        email.textContent = member.email || "";

        const studentClass = document.createElement("p");
        studentClass.textContent = member.studentClass || "";

        card.append(name, email, studentClass);

        membersList.appendChild(card);

    });

}


// ==========================================
// APPROVE OR REJECT MEMBERS
// ==========================================

async function updateMemberStatus(userId, status) {

    if (!currentPresident) return;

    const confirmed = confirm(
        `Are you sure you want to ${status} this application?`
    );

    if (!confirmed) return;

    try {

        await updateDoc(doc(db, "members", userId), {
            status: status
        });

        alert(`Application ${status} successfully!`);

        await loadDashboard();

    } catch (error) {

        console.error("Member update error:", error);

        alert("Unable to update application.");

    }

}


// ==========================================
// CREATE ANNOUNCEMENT
// ==========================================

if (announcementForm) {

    announcementForm.addEventListener("submit", async event => {

        event.preventDefault();

        if (!currentPresident) return;

        const title = document.getElementById("announcementTitle").value.trim();
        const category = document.getElementById("announcementCategory").value;
        const content = document.getElementById("announcementContent").value.trim();

        if (!title || !category || !content) {
            alert("Please complete all announcement fields.");
            return;
        }

        const button = document.getElementById("publishAnnouncement");

        button.disabled = true;
        button.textContent = "Publishing...";

        try {

            await addDoc(collection(db, "announcements"), {

                title: title,
                category: category,
                content: content,
                published: true,
                createdBy: currentPresident.uid,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()

            });

            alert("Announcement published successfully!");

            announcementForm.reset();

            await loadAnnouncements();

        } catch (error) {

            console.error("Announcement error:", error);

            alert("Unable to publish announcement. Check your Firebase permissions.");

        } finally {

            button.disabled = false;
            button.innerHTML = "Publish Announcement";

        }

    });

}


// ==========================================
// LOAD ANNOUNCEMENTS
// ==========================================

async function loadAnnouncements() {

    if (!announcementList) return;

    announcementList.textContent = "Loading announcements...";

    try {

        const snapshot = await getDocs(
            collection(db, "announcements")
        );

        announcementList.innerHTML = "";

        const announcements = [];

        snapshot.forEach(item => {

            announcements.push({
                id: item.id,
                ...item.data()
            });

        });

        announcements.sort((a, b) => {
            return getTimestamp(b.createdAt) - getTimestamp(a.createdAt);
        });

        if (announcements.length === 0) {

            announcementList.textContent =
                "No announcements published yet.";

            return;
        }

        announcements.forEach(item => {

            if (item.published !== true) return;

            const card = document.createElement("div");
            card.className = "admin-member-card";

            const title = document.createElement("h3");
            title.textContent = item.title;

            const category = document.createElement("p");
            category.textContent = "Category: " + item.category;

            const content = document.createElement("p");
            content.textContent = item.content;

            const editButton = document.createElement("button");
            editButton.textContent = "Edit";
            editButton.className = "approve-button";

            editButton.addEventListener("click", () => {
                editAnnouncement(item);
            });

            const deleteButton = document.createElement("button");
            deleteButton.textContent = "Delete";
            deleteButton.className = "reject-button";

            deleteButton.addEventListener("click", () => {
                deleteAnnouncement(item.id);
            });

            card.append(
                title,
                category,
                content,
                editButton,
                deleteButton
            );

            announcementList.appendChild(card);

        });

    } catch (error) {

        console.error("Announcement loading error:", error);

        announcementList.textContent =
            "Unable to load announcements. Check Firebase permissions.";

    }

}


// ==========================================
// EDIT ANNOUNCEMENT
// ==========================================

async function editAnnouncement(item) {

    const title = prompt("Edit announcement title:", item.title);

    if (title === null) return;

    const category = prompt(
        "Edit category:",
        item.category
    );

    if (category === null) return;

    const content = prompt(
        "Edit announcement:",
        item.content
    );

    if (content === null) return;

    if (!title.trim() || !content.trim()) {
        alert("Title and announcement cannot be empty.");
        return;
    }

    const allowedCategories = [
        "General",
        "Important",
        "Meeting",
        "Workshop",
        "Competition"
    ];

    if (!allowedCategories.includes(category.trim())) {
        alert("Please use a valid announcement category.");
        return;
    }

    try {

        await updateDoc(doc(db, "announcements", item.id), {

            title: title.trim(),
            category: category.trim(),
            content: content.trim(),
            updatedAt: serverTimestamp()

        });

        alert("Announcement updated successfully!");

        await loadAnnouncements();

    } catch (error) {

        console.error("Announcement update error:", error);

        alert("Unable to update announcement.");

    }

}


// ==========================================
// DELETE ANNOUNCEMENT
// ==========================================

async function deleteAnnouncement(id) {

    if (!confirm("Are you sure you want to delete this announcement?")) {
        return;
    }

    try {

        await deleteDoc(doc(db, "announcements", id));

        alert("Announcement deleted successfully!");

        await loadAnnouncements();

    } catch (error) {

        console.error("Announcement deletion error:", error);

        alert("Unable to delete announcement.");

    }

}


// ==========================================
// CREATE EVENT
// ==========================================

if (eventForm) {

    eventForm.addEventListener("submit", async event => {

        event.preventDefault();

        if (!currentPresident) return;

        const title = document.getElementById("eventTitle").value.trim();
        const category = document.getElementById("eventCategory").value;
        const date = document.getElementById("eventDate").value;
        const time = document.getElementById("eventTime").value;
        const venue = document.getElementById("eventVenue").value.trim();
        const description = document.getElementById("eventDescription").value.trim();

        if (!title || !category || !date || !time || !venue || !description) {
            alert("Please complete all event fields.");
            return;
        }

        const button = document.getElementById("publishEvent");

        button.disabled = true;
        button.textContent = "Publishing...";

        try {

            await addDoc(collection(db, "events"), {

                title: title,
                category: category,
                date: date,
                time: time,
                venue: venue,
                description: description,
                published: true,
                createdBy: currentPresident.uid,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()

            });

            alert("Event published successfully!");

            eventForm.reset();

            await loadEvents();

        } catch (error) {

            console.error("Event publishing error:", error);

            alert("Unable to publish event. Check your Firebase permissions.");

        } finally {

            button.disabled = false;
            button.innerHTML = "Publish Event";

        }

    });

}


// ==========================================
// LOAD EVENTS
// ==========================================

async function loadEvents() {

    if (!eventList) return;

    eventList.textContent = "Loading events...";

    try {

        const snapshot = await getDocs(
            collection(db, "events")
        );

        eventList.innerHTML = "";

        const events = [];

        snapshot.forEach(item => {

            events.push({
                id: item.id,
                ...item.data()
            });

        });

        events.sort((a, b) => {
            return (a.date || "").localeCompare(b.date || "");
        });

        const publishedEvents = events.filter(item =>
            item.published === true
        );

        if (publishedEvents.length === 0) {

            eventList.textContent = "No events published yet.";

            return;
        }

        publishedEvents.forEach(item => {

            const card = document.createElement("div");
            card.className = "admin-member-card";

            const title = document.createElement("h3");
            title.textContent = item.title;

            const category = document.createElement("p");
            category.textContent = "Category: " + item.category;

            const date = document.createElement("p");
            date.textContent = "Date: " + item.date;

            const time = document.createElement("p");
            time.textContent = "Time: " + item.time;

            const venue = document.createElement("p");
            venue.textContent = "Venue: " + item.venue;

            const description = document.createElement("p");
            description.textContent = item.description;

            const editButton = document.createElement("button");
            editButton.textContent = "Edit";
            editButton.className = "approve-button";

            editButton.addEventListener("click", () => {
                editEvent(item);
            });

            const deleteButton = document.createElement("button");
            deleteButton.textContent = "Delete";
            deleteButton.className = "reject-button";

            deleteButton.addEventListener("click", () => {
                deleteEvent(item.id);
            });

            card.append(
                title,
                category,
                date,
                time,
                venue,
                description,
                editButton,
                deleteButton
            );

            eventList.appendChild(card);

        });

    } catch (error) {

        console.error("Event loading error:", error);

        eventList.textContent =
            "Unable to load events. Check Firebase permissions.";

    }

}


// ==========================================
// EDIT EVENT
// ==========================================

async function editEvent(item) {

    const title = prompt("Edit event name:", item.title);
    if (title === null) return;

    const category = prompt("Edit event category:", item.category);
    if (category === null) return;

    const date = prompt("Edit event date (YYYY-MM-DD):", item.date);
    if (date === null) return;

    const time = prompt("Edit event time (HH:MM):", item.time);
    if (time === null) return;

    const venue = prompt("Edit event venue:", item.venue);
    if (venue === null) return;

    const description = prompt("Edit event description:", item.description);
    if (description === null) return;

    const allowedCategories = [
        "Workshop",
        "Competition",
        "Meeting",
        "Training",
        "Other"
    ];

    if (
        !title.trim() ||
        !venue.trim() ||
        !description.trim() ||
        !date.trim() ||
        !time.trim()
    ) {
        alert("Please complete all event fields.");
        return;
    }

    if (!allowedCategories.includes(category.trim())) {
        alert("Please use a valid event category.");
        return;
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date.trim()) ||
        !/^\d{2}:\d{2}$/.test(time.trim())) {
        alert("Please enter the date as YYYY-MM-DD and time as HH:MM.");
        return;
    }

    try {

        await updateDoc(doc(db, "events", item.id), {

            title: title.trim(),
            category: category.trim(),
            date: date.trim(),
            time: time.trim(),
            venue: venue.trim(),
            description: description.trim(),
            updatedAt: serverTimestamp()

        });

        alert("Event updated successfully!");

        await loadEvents();

    } catch (error) {

        console.error("Event update error:", error);

        alert("Unable to update event.");

    }

}


// ==========================================
// DELETE EVENT
// ==========================================

async function deleteEvent(id) {

    if (!confirm("Are you sure you want to delete this event?")) {
        return;
    }

    try {

        await deleteDoc(doc(db, "events", id));

        alert("Event deleted successfully!");

        await loadEvents();

    } catch (error) {

        console.error("Event deletion error:", error);

        alert("Unable to delete event.");

    }

}


// ==========================================
// TIMESTAMP HELPER
// ==========================================

function getTimestamp(value) {

    if (!value) return 0;

    if (typeof value.toMillis === "function") {
        return value.toMillis();
    }

    return 0;

}


// ==========================================
// PRESIDENT THEME SETTINGS
// ==========================================

const themeButton = document.getElementById("adminThemeToggle");

function applyAdminTheme() {

    const savedTheme = localStorage.getItem("acc-admin-theme");

    if (savedTheme === "light") {

        document.body.classList.add("light-mode");

    } else {

        document.body.classList.remove("light-mode");

    }

    updateThemeButton();

}

function updateThemeButton() {

    if (!themeButton) return;

    if (document.body.classList.contains("light-mode")) {

        themeButton.textContent = "Switch to Dark Mode";

    } else {

        themeButton.textContent = "Switch to Light Mode";

    }

}

applyAdminTheme();

if (themeButton) {

    themeButton.addEventListener("click", () => {

        document.body.classList.toggle("light-mode");

        const theme = document.body.classList.contains("light-mode")
            ? "light"
            : "dark";

        localStorage.setItem("acc-admin-theme", theme);

        updateThemeButton();

    });

}


// ==========================================
// SECURE LOGOUT
// ==========================================

async function logoutPresident() {

    const confirmed = confirm("Are you sure you want to log out?");

    if (!confirmed) return;

    try {

        await signOut(auth);

        window.location.href = "login.html";

    } catch (error) {

        console.error("Logout error:", error);

        alert("Logout failed. Please try again.");

    }

}

if (logoutButton) {
    logoutButton.addEventListener("click", logoutPresident);
}

if (settingsLogout) {
    settingsLogout.addEventListener("click", logoutPresident);
}
// ==========================================
// PROJECT SUBMISSION MANAGEMENT
// ==========================================


// LOAD PROJECT SUBMISSIONS

async function loadProjects() {
    
    if (!adminProjectsList) return;
    
    adminProjectsList.textContent = "Loading project submissions...";
    
    try {
        
        const snapshot = await getDocs(
            collection(db, "projectSubmissions")
        );
        console.log("Projects found:", snapshot.size);
        const projects = [];
        
        snapshot.forEach(item => {
            
            projects.push({
                id: item.id,
                ...item.data()
            });
            
        });
        
        // Sort newest submissions first.
        projects.sort((a, b) => {
            return getTimestamp(b.createdAt) -
                getTimestamp(a.createdAt);
        });
        
        // UPDATE STATISTICS
        
        const pending = projects.filter(
            project => project.status === "pending"
        ).length;
        
        const approved = projects.filter(
            project => project.status === "approved"
        ).length;
        
        if (adminTotalProjects) {
            adminTotalProjects.textContent = projects.length;
        }
        
        if (adminPendingProjects) {
            adminPendingProjects.textContent = pending;
        }
        
        if (adminApprovedProjects) {
            adminApprovedProjects.textContent = approved;
        }
        
        displayProjects(projects);
        
    } catch (error) {
        
        console.error("Project loading error:", error);
        
        adminProjectsList.textContent =
            "Unable to load project submissions.";
        
    }
    
}


// DISPLAY PROJECTS

function displayProjects(projects) {
    
    adminProjectsList.innerHTML = "";
    
    if (projects.length === 0) {
        
        adminProjectsList.textContent =
            "No project submissions yet.";
        
        return;
    }
    
    projects.forEach(project => {
        
        const card = document.createElement("div");
        card.className = "admin-member-card";
        
        const title = document.createElement("h3");
        title.textContent = project.title || "Untitled Project";
        
        const member = document.createElement("p");
        member.textContent =
            "Submitted by: " + (project.submittedByName || "Unknown Member");
        
        const category = document.createElement("p");
        category.textContent =
            "Category: " + (project.category || "Other");
        
        const description = document.createElement("p");
        description.textContent =
            project.description || "No description provided.";
        
        const status = document.createElement("p");
        status.textContent =
            "Status: " + (project.status || "pending").toUpperCase();
        
        card.append(
            title,
            member,
            category,
            description,
            status
        );
        
        // PROJECT LINK
        
        if (
            project.link &&
            /^https?:\/\//i.test(project.link)
        ) {
            
            const link = document.createElement("a");
            
            link.href = project.link;
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            link.textContent = "View Submitted Project";
            
            card.appendChild(link);
            
        }
        
        // REVIEW BUTTONS
        
        if (project.status === "pending") {
            
            const approveButton = document.createElement("button");
            
            approveButton.textContent = "Approve Project";
            approveButton.className = "approve-button";
            
            approveButton.addEventListener("click", () => {
                reviewProject(project, "approved");
            });
            
            
            const rejectButton = document.createElement("button");
            
            rejectButton.textContent = "Reject Project";
            rejectButton.className = "reject-button";
            
            rejectButton.addEventListener("click", () => {
                reviewProject(project, "rejected");
            });
            
            card.append(
                approveButton,
                rejectButton
            );
            
        }
        
        // SHOW EXISTING FEEDBACK
        
        if (project.feedback) {
            
            const feedback = document.createElement("p");
            
            feedback.textContent =
                "President's Feedback: " + project.feedback;
            
            card.appendChild(feedback);
            
        }
        
        adminProjectsList.appendChild(card);
        
    });
    
}


// APPROVE OR REJECT PROJECT

async function reviewProject(project, status) {
    
    if (!currentPresident) return;
    
    const action = status === "approved" ?
        "approve" :
        "reject";
    
    const confirmed = confirm(
        `Are you sure you want to ${action} this project?`
    );
    
    if (!confirmed) return;
    
    const feedback = prompt(
        "Enter feedback for the member (optional):"
    );
    
    if (feedback === null) return;
    
    if (feedback.length > 1000) {
        
        alert("Feedback cannot exceed 1000 characters.");
        
        return;
    }
    
    try {
        
        await updateDoc(
            doc(db, "projectSubmissions", project.id),
            {
                status: status,
                reviewedAt: serverTimestamp(),
                reviewedBy: currentPresident.uid,
                feedback: feedback.trim()
            }
        );
        
        alert(`Project ${status} successfully!`);
        
        await loadProjects();
        console.log("President project loader started");
        
    } catch (error) {
        
        console.error("Project review error:", error);
        
        alert(
            "Unable to review this project. Check your Firebase permissions."
        );
        
    }
    
}