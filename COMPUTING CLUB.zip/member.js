// ==========================================
// ASANTEMAN COMPUTING CLUB
// MEMBER DASHBOARD
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
    doc,
    getDoc,
    collection,
    getDocs,
    query,
    where
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";

// ==========================================
// 1. ELEMENTS
// ==========================================

const sidebar = document.getElementById("memberSidebar");
const overlay = document.getElementById("sidebarOverlay");
const toggle = document.getElementById("sidebarToggle");

// ==========================================
// 2. MOBILE SIDEBAR
// ==========================================

function openSidebar() {
    if (!sidebar || !overlay || !toggle) return;

    sidebar.classList.add("open");
    overlay.classList.add("show");
    toggle.setAttribute("aria-expanded", "true");
}

function closeSidebar() {
    if (!sidebar || !overlay || !toggle) return;

    sidebar.classList.remove("open");
    overlay.classList.remove("show");
    toggle.setAttribute("aria-expanded", "false");
}

if (toggle) {
    toggle.addEventListener("click", function() {
        if (sidebar.classList.contains("open")) {
            closeSidebar();
        } else {
            openSidebar();
        }
    });
}

if (overlay) {
    overlay.addEventListener("click", closeSidebar);
}

window.addEventListener("resize", function() {
    if (window.innerWidth > 900) {
        closeSidebar();
    }
});

// ==========================================
// 3. MEMBER NAVIGATION
// ==========================================


const memberLinks = document.querySelectorAll(".member-nav-link");

memberLinks.forEach(link => {
    
    link.addEventListener("click", function(event) {
        
        const href = this.getAttribute("href");
        
        if (!href) return;
        
        // Allow normal navigation to separate HTML pages
        if (!href.startsWith("#")) {
            closeSidebar();
            return;
        }
        
        event.preventDefault();
        
        const targetId = href.substring(1);
        const targetSection = document.getElementById(targetId);
        
        if (!targetSection) return;
        
        memberLinks.forEach(item => {
            item.classList.remove("active");
        });
        
        this.classList.add("active");
        
        document.querySelectorAll(
            ".member-main .dashboard-section"
        ).forEach(section => {
            section.classList.remove("active");
        });
        
        targetSection.classList.add("active");
        
        targetSection.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
        
        closeSidebar();
        
    });
    
});
// ==========================================
// 4. CURRENT YEAR
// ==========================================

const yearElement = document.getElementById("memberYear");

if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
}

// ==========================================
// 5. LOGOUT
// ==========================================

async function logoutMember() {

    if (!confirm("Are you sure you want to log out?")) {
        return;
    }

    try {
        await signOut(auth);
        window.location.replace("login.html");

    } catch (error) {
        console.error("Logout error:", error);
        alert("Unable to log out. Please try again.");
    }
}

// ==========================================
// 6. CONTENT DISPLAY HELPERS
// ==========================================

function createEmptyMessage(icon, title, message) {

    const card = document.createElement("div");
    card.className = "coming-soon-card";

    const iconElement = document.createElement("i");
    iconElement.className = icon;

    const heading = document.createElement("h3");
    heading.textContent = title;

    const paragraph = document.createElement("p");
    paragraph.textContent = message;

    card.append(iconElement, heading, paragraph);

    return card;
}

function getPostedDate(timestamp) {

    if (!timestamp || !timestamp.toDate) {
        return "Date unavailable";
    }

    return timestamp.toDate().toLocaleString();
}

// ==========================================
// 7. LOAD ANNOUNCEMENTS
// ==========================================

async function loadMemberAnnouncements() {

    const section = document.getElementById("announcements");

    if (!section) return;

    const heading = section.querySelector(
        ".dashboard-section-heading"
    );

    const oldPlaceholder = section.querySelector(
        ".coming-soon-card"
    );

    const container = document.createElement("div");
    container.id = "memberAnnouncementsList";
    container.className = "member-announcements-list";

    container.textContent = "Loading announcements...";

    if (oldPlaceholder) {
        oldPlaceholder.replaceWith(container);
    } else if (!document.getElementById("memberAnnouncementsList")) {
        if (heading) {
            heading.after(container);
        } else {
            section.appendChild(container);
        }
    }

    try {

        const announcementsQuery = query(
            collection(db, "announcements"),
            where("published", "==", true)
        );

        const snapshot = await getDocs(announcementsQuery);

        container.replaceChildren();

        if (snapshot.empty) {

            container.appendChild(
                createEmptyMessage(
                    "fas fa-bullhorn",
                    "No announcements yet",
                    "Club updates will appear here."
                )
            );

            return;
        }

        const announcements = snapshot.docs.map(item => ({
            id: item.id,
            ...item.data()
        }));

        announcements.sort((a, b) => {
            const dateA = a.createdAt?.toMillis?.() || 0;
            const dateB = b.createdAt?.toMillis?.() || 0;

            return dateB - dateA;
        });

        announcements.forEach(announcement => {

            const card = document.createElement("article");
            card.className = "member-announcement-card";

            const category = document.createElement("span");
            category.className = "announcement-category";
            category.textContent = announcement.category || "General";

            const title = document.createElement("h3");
            title.textContent = announcement.title || "Untitled Announcement";

            const content = document.createElement("p");
            content.textContent = announcement.content || "";

            const date = document.createElement("small");
            date.textContent = "Posted: " +
                getPostedDate(announcement.createdAt);

            card.append(category, title, content, date);

            container.appendChild(card);
        });

        console.log("Announcements loaded:", snapshot.size);

    } catch (error) {

        console.error("Announcement loading error:", error);

        container.textContent =
            "Unable to load announcements. Please refresh.";

    }
}

// ==========================================
// 8. LOAD EVENTS
// ==========================================

async function loadMemberEvents() {

    const section = document.getElementById("events");

    if (!section) return;

    const heading = section.querySelector(
        ".dashboard-section-heading"
    );

    const oldPlaceholder = section.querySelector(
        ".coming-soon-card"
    );

    const container = document.createElement("div");
    container.id = "memberEventsList";
    container.className = "member-events-list";

    container.textContent = "Loading events...";

    if (oldPlaceholder) {
        oldPlaceholder.replaceWith(container);
    } else if (!document.getElementById("memberEventsList")) {
        if (heading) {
            heading.after(container);
        } else {
            section.appendChild(container);
        }
    }

    try {

        const eventsQuery = query(
            collection(db, "events"),
            where("published", "==", true)
        );

        const snapshot = await getDocs(eventsQuery);

        container.replaceChildren();

        if (snapshot.empty) {

            container.appendChild(
                createEmptyMessage(
                    "fas fa-calendar-alt",
                    "No events yet",
                    "Stay tuned for upcoming club activities."
                )
            );

            return;
        }

        const events = snapshot.docs.map(item => ({
            id: item.id,
            ...item.data()
        }));

        events.sort((a, b) => {
            return (a.date || "").localeCompare(b.date || "");
        });

        events.forEach(event => {

            const card = document.createElement("article");
            card.className = "member-event-card";

            const category = document.createElement("span");
            category.className = "event-category";
            category.textContent = event.category || "General";

            const title = document.createElement("h3");
            title.textContent = event.title || "Untitled Event";

            const date = document.createElement("p");
            date.innerHTML = '<i class="fas fa-calendar"></i> ';
            date.appendChild(
                document.createTextNode(event.date || "Date not specified")
            );

            const time = document.createElement("p");
            time.innerHTML = '<i class="fas fa-clock"></i> ';
            time.appendChild(
                document.createTextNode(event.time || "Time not specified")
            );

            const venue = document.createElement("p");
            venue.innerHTML = '<i class="fas fa-map-marker-alt"></i> ';
            venue.appendChild(
                document.createTextNode(event.venue || "Venue not specified")
            );

            const description = document.createElement("p");
            description.textContent =
                event.description || "No event description provided.";

            card.append(
                category,
                title,
                date,
                time,
                venue,
                description
            );

            container.appendChild(card);
        });

        console.log("Events loaded:", snapshot.size);

    } catch (error) {

        console.error("Event loading error:", error);

        container.textContent =
            "Unable to load events. Please refresh.";

    }
}

// ==========================================
// 9. FIREBASE ACCESS PROTECTION
// ==========================================

document.body.style.visibility = "hidden";

onAuthStateChanged(auth, async function(user) {

    if (!user) {
        window.location.replace("login.html");
        return;
    }

    try {

        // Check President account
        const adminRef = doc(db, "admins", user.uid);
        const adminSnapshot = await getDoc(adminRef);

        if (adminSnapshot.exists()) {
            window.location.replace("admin.html");
            return;
        }

        // Check member account
        const memberRef = doc(db, "members", user.uid);
        const memberSnapshot = await getDoc(memberRef);

        if (!memberSnapshot.exists()) {
            await signOut(auth);
            window.location.replace("login.html");
            return;
        }

        const member = memberSnapshot.data();

        if (member.status !== "approved") {

            await signOut(auth);

            alert("Your membership has not yet been approved.");

            window.location.replace("login.html");
            return;
        }

        // Load member information
        const fullName = member.fullName ||
            user.displayName ||
            "ACC Member";

        const email = member.email || user.email || "No email";

        const studentClass = member.studentClass || "Not specified";

        const profileName = document.getElementById("profileName");
        const profileEmail = document.getElementById("profileEmail");
        const profileClass = document.getElementById("profileClass");
        const profileStatus = document.getElementById("profileStatus");

        if (profileName) profileName.textContent = fullName;
        if (profileEmail) profileEmail.textContent = email;

        if (profileClass) {
            profileClass.textContent = "Class: " + studentClass;
        }

        if (profileStatus) {
            profileStatus.textContent = "Approved Member";
        }

        const welcomeName = document.getElementById("welcomeName");

        if (welcomeName) {
            welcomeName.textContent = fullName.split(" ")[0];
        }

        const sidebarMemberName =
            document.getElementById("sidebarMemberName");

        if (sidebarMemberName) {
            sidebarMemberName.textContent = fullName;
        }

        // Set member initial
        const memberInitial = document.getElementById("memberInitial");

        if (memberInitial) {
            memberInitial.textContent = fullName.charAt(0).toUpperCase();
        }

        // Load community content
        await Promise.all([
            loadMemberAnnouncements(),
            loadMemberEvents()
        ]);

        // Show dashboard
        document.body.style.visibility = "visible";

        console.log("ACC Member Dashboard loaded successfully!");

    } catch (error) {

        console.error("Member verification error:", error);

        alert("Unable to verify your membership. Please try again.");

        await signOut(auth);

        window.location.replace("login.html");
    }

});

// ==========================================
// 10. LOGOUT BUTTONS
// ==========================================

const logoutButtons = document.querySelectorAll(
    ".member-logout"
);

logoutButtons.forEach(button => {

    button.addEventListener("click", function(event) {
        event.preventDefault();
        logoutMember();
    });

});

// ==========================================
// 11. PROFILE SHORTCUTS
// ==========================================

function openMemberProfile() {

    const profileLink = document.querySelector(
        '.member-nav-link[href="#profile"]'
    );

    if (profileLink) {
        profileLink.click();
    }
}

const profileShortcut = document.getElementById("profileShortcut");
const settingsProfile = document.getElementById("settingsProfile");

if (profileShortcut) {
    profileShortcut.addEventListener("click", openMemberProfile);
}

if (settingsProfile) {
    settingsProfile.addEventListener("click", openMemberProfile);
}

// ==========================================
// 12. SETTINGS LOGOUT
// ==========================================

const settingsLogout = document.getElementById("settingsLogout");

if (settingsLogout) {
    settingsLogout.addEventListener("click", logoutMember);
}

// ==========================================
// 13. THEME SWITCH
// ==========================================

const themeToggle = document.getElementById("themeToggle");

function applyTheme(theme) {

    document.body.classList.toggle(
        "light-mode",
        theme === "light"
    );

    if (themeToggle) {
        themeToggle.textContent =
            theme === "light"
                ? "Switch to Dark Mode"
                : "Switch to Light Mode";
    }

    localStorage.setItem("acc-member-theme", theme);
}

const savedTheme =
    localStorage.getItem("acc-member-theme") || "dark";

applyTheme(savedTheme);

if (themeToggle) {

    themeToggle.addEventListener("click", function() {

        const newTheme =
            document.body.classList.contains("light-mode")
                ? "dark"
                : "light";

        applyTheme(newTheme);
    });
}
// ==========================================
// 15. ACC LEARNING CENTRE
// ==========================================

const courseList = document.getElementById("courseList");
const courseDetails = document.getElementById("courseDetails");
const courseDetailTitle = document.getElementById("courseDetailTitle");
const courseDetailDescription = document.getElementById("courseDetailDescription");
const courseLessonList = document.getElementById("courseLessonList");
const backToCourses = document.getElementById("backToCourses");

const accCourses = {

    programming: {
        title: "Programming",
        description: "Learn how to give computers instructions and develop logical solutions to problems.",
        lessons: [
            {
                title: "Lesson 1: Introduction to Programming",
                content: "Programming is the process of writing instructions that tell a computer what to do. These instructions are written using programming languages such as Python, JavaScript and C++."
            },
            {
                title: "Lesson 2: Programming Languages",
                content: "A programming language allows humans to communicate instructions to computers. Examples include Python, Java, C++, JavaScript and PHP."
            },
            {
                title: "Lesson 3: Variables and Data Types",
                content: "Variables are named storage locations used to hold information. Common data types include integers, floating-point numbers, strings and Boolean values."
            },
            {
                title: "Lesson 4: Operators",
                content: "Operators perform operations on values. Arithmetic operators include addition (+), subtraction (-), multiplication (*) and division (/)."
            },
            {
                title: "Lesson 5: Conditional Statements",
                content: "Conditional statements allow programs to make decisions. Examples include if, else and elif statements in Python."
            }
        ]
    },

    web: {
        title: "Web Development",
        description: "Learn how websites are created using HTML, CSS and JavaScript.",
        lessons: [
            {
                title: "Lesson 1: Introduction to Web Development",
                content: "Web development is the process of creating websites and web applications. It involves frontend development and backend development."
            },
            {
                title: "Lesson 2: Introduction to HTML",
                content: "HTML stands for HyperText Markup Language. It provides the structure of a webpage using elements such as headings, paragraphs, images and links."
            },
            {
                title: "Lesson 3: Introduction to CSS",
                content: "CSS stands for Cascading Style Sheets. It controls the appearance of webpages, including colours, fonts, spacing and layouts."
            },
            {
                title: "Lesson 4: Introduction to JavaScript",
                content: "JavaScript adds interactivity to websites. It can respond to button clicks, validate forms and update webpage content."
            },
            {
                title: "Lesson 5: Building Your First Website",
                content: "A basic website can be created using three technologies: HTML for structure, CSS for design and JavaScript for interactivity."
            }
        ]
    },

    ai: {
        title: "Artificial Intelligence",
        description: "Explore how computers perform tasks that normally require human intelligence.",
        lessons: [
            {
                title: "Lesson 1: Introduction to AI",
                content: "Artificial Intelligence (AI) is a field of computing that develops systems capable of performing tasks such as recognising patterns, understanding language and making predictions."
            },
            {
                title: "Lesson 2: Types of AI",
                content: "AI can be classified in different ways. Narrow AI is designed for specific tasks, while Artificial General Intelligence describes a theoretical system with broader human-like abilities."
            },
            {
                title: "Lesson 3: Machine Learning",
                content: "Machine Learning is a branch of AI that allows computer systems to learn patterns from data and use those patterns to make predictions."
            },
            {
                title: "Lesson 4: Applications of AI",
                content: "AI is used in healthcare, education, transportation, agriculture, security and many other fields."
            },
            {
                title: "Lesson 5: Responsible AI",
                content: "Responsible AI involves using artificial intelligence fairly, safely and transparently while respecting privacy and avoiding harmful bias."
            }
        ]
    },

    cybersecurity: {
        title: "Cybersecurity",
        description: "Learn how to protect computers, networks and information from digital threats.",
        lessons: [
            {
                title: "Lesson 1: Introduction to Cybersecurity",
                content: "Cybersecurity is the practice of protecting computers, networks, applications and information from unauthorised access and digital attacks."
            },
            {
                title: "Lesson 2: Common Cyber Threats",
                content: "Common threats include phishing, malware, identity theft and online scams. Learning to recognise suspicious activity helps people stay safer online."
            },
            {
                title: "Lesson 3: Password Security",
                content: "Use long, unique passwords for different accounts. A password manager and multi-factor authentication can provide additional protection."
            },
            {
                title: "Lesson 4: Safe Internet Practices",
                content: "Avoid suspicious links, verify websites before sharing information, keep software updated and use trusted networks."
            },
            {
                title: "Lesson 5: Data Protection",
                content: "Data protection involves keeping personal and organisational information secure through access controls, backups and responsible handling."
            }
        ]
    }

};


// OPEN A COURSE

if (courseList) {

    courseList.addEventListener("click", function(event) {

        const button = event.target.closest(".course-open-btn");

        if (!button) return;

        const course = accCourses[button.dataset.course];

        if (!course) return;

        courseDetailTitle.textContent = course.title;
        courseDetailDescription.textContent = course.description;

        courseLessonList.innerHTML = "";

        course.lessons.forEach((lesson, index) => {

            const lessonCard = document.createElement("div");
            lessonCard.className = "course-lesson-card";

            const lessonButton = document.createElement("button");
            lessonButton.type = "button";
            lessonButton.className = "course-lesson-btn";
            lessonButton.innerHTML = `
                <span>${lesson.title}</span>
                <i class="fas fa-chevron-down"></i>
            `;

            const lessonContent = document.createElement("div");
            lessonContent.className = "course-lesson-content";
            lessonContent.hidden = true;
            lessonContent.textContent = lesson.content;

            lessonButton.addEventListener("click", function() {

                const isOpen = !lessonContent.hidden;

                lessonContent.hidden = isOpen;

                lessonButton.querySelector("i").className =
                    isOpen ? "fas fa-chevron-down" : "fas fa-chevron-up";

            });

            lessonCard.appendChild(lessonButton);
            lessonCard.appendChild(lessonContent);

            courseLessonList.appendChild(lessonCard);

        });

        courseList.hidden = true;
        courseDetails.hidden = false;

        courseDetails.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    });

}


// BACK TO COURSE LIST

if (backToCourses) {

    backToCourses.addEventListener("click", function() {

        courseDetails.hidden = true;
        courseList.hidden = false;

        courseList.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    });

}