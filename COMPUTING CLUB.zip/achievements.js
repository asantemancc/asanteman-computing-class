// ==========================================
// ASANTEMAN COMPUTING CLUB
// ACHIEVEMENTS SYSTEM
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

console.log("ACHIEVEMENTS JS IS RUNNING!");
import {
    doc,
    getDoc,
    collection,
    getDocs,
    query,
    where
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";


// ==========================================
// 1. DOM ELEMENTS
// ==========================================

const sidebar = document.getElementById("memberSidebar");
const overlay = document.getElementById("memberOverlay");
const sidebarToggle = document.getElementById("memberSidebarToggle");

const logoutButton = document.getElementById("achievementsLogout");

const achievementGrid = document.getElementById("achievementGrid");
const leaderboard = document.getElementById("achievementLeaderboard");

const badgesEarned = document.getElementById("badgesEarned");
const totalPoints = document.getElementById("totalPoints");
const completedActivities = document.getElementById("completedActivities");

const achievementMessage = document.getElementById("achievementMessage");


// ==========================================
// 2. SIDEBAR
// ==========================================

function openSidebar() {
    sidebar?.classList.add("active");
    overlay?.classList.add("active");
}

function closeSidebar() {
    sidebar?.classList.remove("active");
    overlay?.classList.remove("active");
}

sidebarToggle?.addEventListener("click", openSidebar);
overlay?.addEventListener("click", closeSidebar);


// ==========================================
// 3. LOGOUT
// ==========================================

logoutButton?.addEventListener("click", async () => {

    if (!confirm("Are you sure you want to log out?")) return;

    try {
        await signOut(auth);
        window.location.href = "login.html";

    } catch (error) {
        console.error(error);
        alert("Unable to log out. Please try again.");
    }

});


// ==========================================
// 4. USER INFORMATION
// ==========================================

let currentUser = null;
let currentMember = null;


// ==========================================
// 5. LOAD LOCAL PROGRESS
// ==========================================

function getChallengeProgress() {

    try {

        const saved = localStorage.getItem(
            `accChallenges_${currentUser.uid}`
        );

        const progress = saved ? JSON.parse(saved) : [];

        return Array.isArray(progress) ? progress : [];

    } catch (error) {

        console.error("Challenge progress error:", error);
        return [];

    }

}


function getQuizProgress() {

    try {

        const saved = localStorage.getItem(
            `accQuizStats_${currentUser.uid}`
        );

        if (!saved) {
            return {
                attempts: 0,
                correct: 0,
                best: 0
            };
        }

        const stats = JSON.parse(saved);

        return {
            attempts: Math.max(0, Number(stats.attempts) || 0),
            correct: Math.max(0, Number(stats.correct) || 0),
            best: Math.max(0, Math.min(100, Number(stats.best) || 0))
        };

    } catch (error) {

        console.error("Quiz progress error:", error);

        return {
            attempts: 0,
            correct: 0,
            best: 0
        };

    }

}


// ==========================================
// 6. LOAD APPROVED PROJECTS
// ==========================================

async function getApprovedProjects() {

    try {

        const projectsQuery = query(
            collection(db, "projectSubmissions"),
            where("submittedBy", "==", currentUser.uid),
            where("status", "==", "approved")
        );

        const snapshot = await getDocs(projectsQuery);

        return snapshot.size;

    } catch (error) {

        console.error("Approved projects error:", error);

        throw new Error("Unable to load approved projects.");
    }

}


// ==========================================
// 7. ACHIEVEMENT DEFINITIONS
// ==========================================

const achievements = [

    {
        id: "beginner",
        name: "Beginner",
        icon: "fa-seedling",
        description: "Complete your first coding challenge.",
        requirement: "Complete 1 challenge",
        points: 10,
        unlocked: data => data.challenges >= 1
    },

    {
        id: "coder",
        name: "Coder",
        icon: "fa-laptop-code",
        description: "Complete five coding challenges.",
        requirement: "Complete 5 challenges",
        points: 30,
        unlocked: data => data.challenges >= 5
    },

    {
        id: "quiz-starter",
        name: "Quiz Starter",
        icon: "fa-brain",
        description: "Complete your first quiz.",
        requirement: "Complete 1 quiz",
        points: 10,
        unlocked: data => data.attempts >= 1
    },

    {
        id: "quiz-master",
        name: "Quiz Master",
        icon: "fa-award",
        description: "Achieve a perfect score in a quiz.",
        requirement: "Get 100% in a quiz",
        points: 30,
        unlocked: data => data.best >= 100 && data.attempts >= 1
    },

    {
        id: "project-builder",
        name: "Project Builder",
        icon: "fa-rocket",
        description: "Get your first project approved.",
        requirement: "Get 1 project approved",
        points: 50,
        unlocked: data => data.projects >= 1
    },

    {
        id: "rising-star",
        name: "Rising Star",
        icon: "fa-star",
        description: "Earn 100 achievement points.",
        requirement: "Earn 100 points",
        points: 0,
        unlocked: data => data.points >= 100
    },

    {
        id: "acc-champion",
        name: "ACC Champion",
        icon: "fa-crown",
        description: "Reach 250 achievement points.",
        requirement: "Earn 250 points",
        points: 0,
        unlocked: data => data.points >= 250
    }

];


// ==========================================
// 8. CALCULATE ACHIEVEMENTS
// ==========================================

function calculateAchievements(challenges, quiz, projects) {

    const challengeCount = challenges.length;

    const pointsFromChallenges = challengeCount * 10;

    const pointsFromQuizzes = quiz.correct;

    const pointsFromProjects = projects * 50;

    const points = (
        pointsFromChallenges +
        pointsFromQuizzes +
        pointsFromProjects
    );

    const data = {
        challenges: challengeCount,
        attempts: quiz.attempts,
        correct: quiz.correct,
        best: quiz.best,
        projects: projects,
        points: points
    };

    const unlocked = achievements.filter(
        achievement => achievement.unlocked(data)
    );

    return {
        data,
        unlocked,
        points
    };

}


// ==========================================
// 9. DISPLAY STATISTICS
// ==========================================

function displayStatistics(result) {

    const activities =
        result.data.challenges +
        result.data.attempts +
        result.data.projects;

    badgesEarned.textContent = result.unlocked.length;

    totalPoints.textContent = result.points;

    completedActivities.textContent = activities;

}


// ==========================================
// 10. DISPLAY BADGES
// ==========================================

function displayAchievements(result) {

    achievementGrid.innerHTML = "";

    achievements.forEach(achievement => {

        const isUnlocked = result.unlocked.some(
            item => item.id === achievement.id
        );

        const card = document.createElement("div");

        card.className = "achievement-card";

        if (!isUnlocked) {
            card.classList.add("locked");
        }

        const icon = document.createElement("div");
        icon.className = "achievement-icon";

        const iconElement = document.createElement("i");
        iconElement.className = `fas ${achievement.icon}`;

        icon.appendChild(iconElement);

        const title = document.createElement("h3");
        title.textContent = achievement.name;

        const description = document.createElement("p");
        description.textContent = achievement.description;

        const requirement = document.createElement("p");
        requirement.textContent = achievement.requirement;

        const status = document.createElement("span");

        status.className = "achievement-status";

        status.textContent = isUnlocked
            ? "Unlocked"
            : "Locked";

        card.append(
            icon,
            title,
            description,
            requirement,
            status
        );

        achievementGrid.appendChild(card);

    });

}


// ==========================================
// 11. LEADERBOARD NOTICE
// ==========================================

function displayLeaderboardNotice() {

    leaderboard.innerHTML = "";

    const message = document.createElement("p");

    message.textContent =
        "The ACC leaderboard will be available when member progress syncing is connected to Firebase.";

    leaderboard.appendChild(message);

}


// ==========================================
// 12. LOAD ALL ACHIEVEMENTS
// ==========================================

async function loadAchievements() {

    achievementGrid.textContent = "Loading achievements...";

    try {

        const challenges = getChallengeProgress();

        const quiz = getQuizProgress();

        const projects = await getApprovedProjects();

        const result = calculateAchievements(
            challenges,
            quiz,
            projects
        );

        displayStatistics(result);

        displayAchievements(result);

        displayLeaderboardNotice();

        achievementMessage.style.display = "block";

        achievementMessage.textContent =
            `You have unlocked ${result.unlocked.length} achievement badges. Keep learning and building!`;

        console.log("ACC achievements loaded successfully!");

    } catch (error) {

        console.error("Achievement loading error:", error);

        achievementGrid.textContent =
            "Unable to load achievements. Please refresh the page.";

        leaderboard.textContent =
            "Leaderboard unavailable.";

    }

}


// ==========================================
// 13. FIREBASE AUTHENTICATION
// ==========================================

document.body.style.display = "none";

onAuthStateChanged(auth, async user => {

    if (!user) {

        window.location.href = "login.html";
        return;

    }

    currentUser = user;

    try {

        // Check administrator account.
        const adminRef = doc(db, "admins", user.uid);

        const adminSnap = await getDoc(adminRef);

        if (adminSnap.exists()) {

            window.location.href = "admin.html";
            return;

        }

        // Check member account.
        const memberRef = doc(db, "members", user.uid);

        const memberSnap = await getDoc(memberRef);

        if (!memberSnap.exists()) {

            await signOut(auth);

            window.location.href = "login.html";
            return;

        }

        currentMember = memberSnap.data();

        if (currentMember.status !== "approved") {

            alert("Your membership has not yet been approved.");

            await signOut(auth);

            window.location.href = "login.html";
            return;

        }

        // Restore theme.
        if (
            localStorage.getItem("acc-member-theme") === "light"
        ) {

            document.body.classList.add("light-theme");

        }

        await loadAchievements();

        document.body.style.display = "";

    } catch (error) {

        console.error("Achievement authentication error:", error);

        alert("Unable to load your achievements.");

        window.location.href = "login.html";

    }

});