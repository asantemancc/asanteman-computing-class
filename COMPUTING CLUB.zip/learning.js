// ==========================================
// ASANTEMAN COMPUTING CLUB
// LEARNING CENTRE
// ==========================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";


// ==========================================
// 1. SIDEBAR NAVIGATION
// ==========================================

const sidebar = document.getElementById("memberSidebar");
const overlay = document.getElementById("sidebarOverlay");
const sidebarToggle = document.getElementById("sidebarToggle");

function openSidebar() {
    if (sidebar) sidebar.classList.add("active");
    if (overlay) overlay.classList.add("active");
}

function closeSidebar() {
    if (sidebar) sidebar.classList.remove("active");
    if (overlay) overlay.classList.remove("active");
}

if (sidebarToggle) {
    sidebarToggle.addEventListener("click", openSidebar);
}

if (overlay) {
    overlay.addEventListener("click", closeSidebar);
}

document.querySelectorAll(".member-nav-link").forEach(link => {
    link.addEventListener("click", closeSidebar);
});


// ==========================================
// 2. LOGOUT
// ==========================================

const logoutButton = document.getElementById("learningLogout");

if (logoutButton) {
    logoutButton.addEventListener("click", async () => {

        const confirmed = confirm("Are you sure you want to log out?");

        if (!confirmed) return;

        try {
            await signOut(auth);
            window.location.href = "login.html";
        } catch (error) {
            alert("Logout failed. Please try again.");
            console.error(error);
        }

    });
}


// ==========================================
// 3. COURSE DATA
// ==========================================

const courses = {

    programming: {
        title: "Python Programming",
        description: "Learn the foundations of programming using Python.",
        lessons: [

            {
                title: "Introduction to Python",
                content: `
                    <h2>Introduction to Python</h2>

                    <p>
                        Python is a high-level programming language known
                        for its simple and readable syntax.
                    </p>

                    <h3>What is programming?</h3>

                    <p>
                        Programming is the process of writing instructions
                        that tell a computer what to do.
                    </p>

                    <h3>Why learn Python?</h3>

                    <ul>
                        <li>It is beginner-friendly.</li>
                        <li>It is used in artificial intelligence.</li>
                        <li>It is used in web development.</li>
                        <li>It is useful for data analysis.</li>
                    </ul>

                    <h3>Your first Python program</h3>

                    <pre>print("Hello, World!")</pre>

                    <p>
                        The <code>print()</code> function displays information
                        on the screen.
                    </p>

                    <div class="resource-box">
                        <strong>Try it:</strong>
                        Write a Python program that displays your name.
                    </div>
                `,
                video: "Python programming for beginners tutorial"
            },

            {
                title: "Variables and Data Types",
                content: `
                    <h2>Variables and Data Types</h2>

                    <p>
                        A variable is a named storage location used to
                        hold information in a program.
                    </p>

                    <h3>Creating variables</h3>

                    <pre>
name = "John"
age = 17
height = 1.75
is_student = True
                    </pre>

                    <h3>Common Python data types</h3>

                    <ul>
                        <li><code>str</code> - Text</li>
                        <li><code>int</code> - Whole numbers</li>
                        <li><code>float</code> - Decimal numbers</li>
                        <li><code>bool</code> - True or False values</li>
                    </ul>

                    <h3>Displaying a variable</h3>

                    <pre>
name = "John"
print(name)
                    </pre>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Create variables for your name, age and favourite subject.
                        Display all three.
                    </div>
                `,
                video: "Python variables and data types beginner tutorial"
            },

            {
                title: "Conditional Statements",
                content: `
                    <h2>Conditional Statements</h2>

                    <p>
                        Conditional statements allow a program to make
                        decisions based on whether a condition is true or false.
                    </p>

                    <h3>The if statement</h3>

                    <pre>
age = 18

if age >= 18:
    print("You are an adult")
                    </pre>

                    <h3>Using if and else</h3>

                    <pre>
marks = 75

if marks >= 50:
    print("Pass")
else:
    print("Fail")
                    </pre>

                    <h3>Using elif</h3>

                    <pre>
score = 80

if score >= 80:
    print("Excellent")
elif score >= 50:
    print("Pass")
else:
    print("Try again")
                    </pre>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Write a program that checks whether a number is positive,
                        negative or zero.
                    </div>
                `,
                video: "Python if else elif statements tutorial"
            },

            {
                title: "Loops",
                content: `
                    <h2>Loops in Python</h2>

                    <p>
                        A loop repeats a block of code several times.
                        Python has two common types of loops.
                    </p>

                    <h3>For loop</h3>

                    <pre>
for number in range(5):
    print(number)
                    </pre>

                    <p>
                        This displays numbers from 0 to 4.
                    </p>

                    <h3>While loop</h3>

                    <pre>
count = 1

while count <= 5:
    print(count)
    count += 1
                    </pre>

                    <p>
                        The while loop continues as long as its condition
                        remains true.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Use a for loop to display numbers from 1 to 10.
                    </div>
                `,
                video: "Python for loops and while loops tutorial"
            },

            {
                title: "Functions",
                content: `
                    <h2>Functions in Python</h2>

                    <p>
                        A function is a reusable block of code that performs
                        a particular task.
                    </p>

                    <h3>Creating a function</h3>

                    <pre>
def greet():
    print("Welcome to ACC!")

greet()
                    </pre>

                    <h3>Functions with parameters</h3>

                    <pre>
def greet(name):
    print("Hello", name)

greet("Ama")
                    </pre>

                    <h3>Using return</h3>

                    <pre>
def add(a, b):
    return a + b

answer = add(5, 3)
print(answer)
                    </pre>

                    <p>
                        <code>return</code> sends a result back from a function,
                        while <code>print()</code> displays information.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Create a function that multiplies two numbers
                        and returns the answer.
                    </div>
                `,
                video: "Python functions parameters and return tutorial"
            }

        ]
    },


    web: {
        title: "Web Development",
        description: "Learn how websites are built using HTML, CSS and JavaScript.",
        lessons: [

            {
                title: "Introduction to Web Development",
                content: `
                    <h2>Introduction to Web Development</h2>

                    <p>
                        Web development is the process of creating websites
                        and web applications.
                    </p>

                    <h3>The three main technologies</h3>

                    <ul>
                        <li><strong>HTML:</strong> Provides the structure.</li>
                        <li><strong>CSS:</strong> Controls the appearance.</li>
                        <li><strong>JavaScript:</strong> Adds interactivity.</li>
                    </ul>

                    <h3>How they work together</h3>

                    <p>
                        HTML creates the content, CSS styles it, and
                        JavaScript makes it interactive.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Identify three websites you use and list some
                        features you think require JavaScript.
                    </div>
                `,
                video: "HTML CSS JavaScript web development beginner tutorial"
            },

            {
                title: "HTML Fundamentals",
                content: `
                    <h2>HTML Fundamentals</h2>

                    <p>
                        HTML means HyperText Markup Language.
                        It is used to structure web pages.
                    </p>

                    <h3>Basic HTML document</h3>

                    <pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
    &lt;title&gt;My Website&lt;/title&gt;
&lt;/head&gt;

&lt;body&gt;
    &lt;h1&gt;Welcome&lt;/h1&gt;
    &lt;p&gt;This is my first website.&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;
                    </pre>

                    <h3>Common HTML elements</h3>

                    <ul>
                        <li><code>&lt;h1&gt;</code> - Main heading</li>
                        <li><code>&lt;p&gt;</code> - Paragraph</li>
                        <li><code>&lt;img&gt;</code> - Image</li>
                        <li><code>&lt;a&gt;</code> - Link</li>
                        <li><code>&lt;button&gt;</code> - Button</li>
                    </ul>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Create a page containing a heading, paragraph and link.
                    </div>
                `,
                video: "HTML tutorial for beginners"
            },

            {
                title: "CSS Fundamentals",
                content: `
                    <h2>CSS Fundamentals</h2>

                    <p>
                        CSS means Cascading Style Sheets.
                        It controls the design and layout of websites.
                    </p>

                    <h3>Example CSS</h3>

                    <pre>
h1 {
    color: purple;
    text-align: center;
}

p {
    font-size: 18px;
}
                    </pre>

                    <h3>Three ways to add CSS</h3>

                    <ul>
                        <li>Inline CSS</li>
                        <li>Internal CSS</li>
                        <li>External CSS</li>
                    </ul>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Style a heading with a colour and centre it on a page.
                    </div>
                `,
                video: "CSS tutorial for beginners"
            },

            {
                title: "JavaScript Fundamentals",
                content: `
                    <h2>JavaScript Fundamentals</h2>

                    <p>
                        JavaScript is a programming language used to make
                        websites interactive.
                    </p>

                    <h3>Displaying a message</h3>

                    <pre>
alert("Welcome to ACC!");
                    </pre>

                    <h3>Variables</h3>

                    <pre>
let name = "Ama";
const school = "Asanteman SHS";
                    </pre>

                    <h3>Functions</h3>

                    <pre>
function greet() {
    alert("Hello!");
}

greet();
                    </pre>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Create a JavaScript variable containing your name
                        and display it using alert().
                    </div>
                `,
                video: "JavaScript tutorial for beginners"
            }

        ]
    },


    ai: {
        title: "Artificial Intelligence",
        description: "Explore artificial intelligence and machine learning.",
        lessons: [

            {
                title: "What is Artificial Intelligence?",
                content: `
                    <h2>What is Artificial Intelligence?</h2>

                    <p>
                        Artificial Intelligence (AI) is a field of computing
                        that focuses on creating systems that perform tasks
                        normally associated with human intelligence.
                    </p>

                    <h3>Examples of AI</h3>

                    <ul>
                        <li>Voice assistants</li>
                        <li>Image recognition</li>
                        <li>Recommendation systems</li>
                        <li>Language translation</li>
                        <li>AI chatbots</li>
                    </ul>

                    <h3>Applications of AI</h3>

                    <p>
                        AI is used in education, healthcare, agriculture,
                        transport and business.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Identify three examples of AI that you have encountered.
                    </div>
                `,
                video: "Artificial intelligence explained for beginners"
            },

            {
                title: "Machine Learning",
                content: `
                    <h2>Machine Learning</h2>

                    <p>
                        Machine Learning is a branch of AI that allows
                        computer systems to learn patterns from data.
                    </p>

                    <h3>Types of Machine Learning</h3>

                    <ul>
                        <li>Supervised learning</li>
                        <li>Unsupervised learning</li>
                        <li>Reinforcement learning</li>
                    </ul>

                    <h3>Example</h3>

                    <p>
                        A system can learn to recognise spam emails by
                        studying examples of spam and normal messages.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Explain one difference between supervised and
                        unsupervised learning.
                    </div>
                `,
                video: "Machine learning explained for beginners"
            },

            {
                title: "Neural Networks",
                content: `
                    <h2>Neural Networks</h2>

                    <p>
                        Neural networks are computing models inspired
                        by the way biological brains process information.
                    </p>

                    <h3>Main components</h3>

                    <ul>
                        <li>Input layer</li>
                        <li>Hidden layers</li>
                        <li>Output layer</li>
                    </ul>

                    <p>
                        Information passes through these layers to produce
                        a result.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Draw a simple neural network with an input layer,
                        one hidden layer and an output layer.
                    </div>
                `,
                video: "Neural networks explained simply"
            },

            {
                title: "Responsible AI",
                content: `
                    <h2>Responsible AI</h2>

                    <p>
                        Responsible AI means developing and using artificial
                        intelligence in ways that are safe, fair and beneficial.
                    </p>

                    <h3>Important considerations</h3>

                    <ul>
                        <li>Privacy protection</li>
                        <li>Fairness</li>
                        <li>Transparency</li>
                        <li>Accuracy</li>
                        <li>Human oversight</li>
                    </ul>

                    <p>
                        AI can make mistakes. Important decisions should
                        not rely blindly on AI-generated information.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Describe two possible risks of using AI irresponsibly.
                    </div>
                `,
                video: "Responsible artificial intelligence explained"
            }

        ]
    },


    cybersecurity: {
        title: "Cybersecurity",
        description: "Learn how to protect computers, networks and information.",
        lessons: [

            {
                title: "Introduction to Cybersecurity",
                content: `
                    <h2>Introduction to Cybersecurity</h2>

                    <p>
                        Cybersecurity is the practice of protecting computers,
                        networks, systems and information from digital threats.
                    </p>

                    <h3>The CIA Triad</h3>

                    <ul>
                        <li><strong>Confidentiality:</strong> Information is accessed only by authorised people.</li>
                        <li><strong>Integrity:</strong> Information remains accurate and unchanged without permission.</li>
                        <li><strong>Availability:</strong> Information and systems are accessible when needed.</li>
                    </ul>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Explain the three parts of the CIA Triad.
                    </div>
                `,
                video: "Cybersecurity fundamentals for beginners"
            },

            {
                title: "Common Cyber Threats",
                content: `
                    <h2>Common Cyber Threats</h2>

                    <p>
                        A cyber threat is a possible danger to a computer,
                        network or digital information.
                    </p>

                    <h3>Examples</h3>

                    <ul>
                        <li><strong>Phishing:</strong> Fake messages designed to trick people.</li>
                        <li><strong>Malware:</strong> Harmful software.</li>
                        <li><strong>Ransomware:</strong> Malware that blocks access to information until demands are made.</li>
                        <li><strong>Social engineering:</strong> Manipulating people into revealing information.</li>
                    </ul>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Give two warning signs of a suspicious email.
                    </div>
                `,
                video: "Common cyber threats explained"
            },

            {
                title: "Passwords and Authentication",
                content: `
                    <h2>Passwords and Authentication</h2>

                    <p>
                        Authentication is the process of verifying the identity
                        of a person or system.
                    </p>

                    <h3>Good account security habits</h3>

                    <ul>
                        <li>Use long, unique passwords.</li>
                        <li>Never share your passwords.</li>
                        <li>Use a password manager where appropriate.</li>
                        <li>Enable multi-factor authentication.</li>
                        <li>Be careful with unexpected login requests.</li>
                    </ul>

                    <h3>Multi-factor authentication</h3>

                    <p>
                        This adds another verification step to an account,
                        making unauthorised access more difficult.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Explain why using the same password for every account
                        is a poor security practice.
                    </div>
                `,
                video: "Password security and multi factor authentication explained"
            },

            {
                title: "Online Privacy and Safety",
                content: `
                    <h2>Online Privacy and Safety</h2>

                    <p>
                        Online privacy involves protecting personal information
                        when using digital services.
                    </p>

                    <h3>Protect yourself online</h3>

                    <ul>
                        <li>Think before sharing personal information.</li>
                        <li>Check website addresses before signing in.</li>
                        <li>Keep software updated.</li>
                        <li>Review app permissions.</li>
                        <li>Report suspicious online activity.</li>
                    </ul>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        List five ways students can stay safe online.
                    </div>
                `,
                video: "Online privacy and internet safety for students"
            }

        ]
    },


    databases: {
        title: "Database Fundamentals",
        description: "Understand how data is organised and managed.",
        lessons: [

            {
                title: "Introduction to Databases",
                content: `
                    <h2>Introduction to Databases</h2>

                    <p>
                        A database is an organised collection of information
                        that can be stored, accessed and managed.
                    </p>

                    <h3>Why use databases?</h3>

                    <ul>
                        <li>Store large amounts of information.</li>
                        <li>Find information quickly.</li>
                        <li>Update records.</li>
                        <li>Organise information.</li>
                    </ul>

                    <p>
                        Schools use databases to manage student records,
                        subjects and examination results.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Give three examples of information a school
                        might store in a database.
                    </div>
                `,
                video: "Database concepts for beginners"
            },

            {
                title: "Tables, Records and Fields",
                content: `
                    <h2>Tables, Records and Fields</h2>

                    <p>
                        Relational databases organise information into tables.
                    </p>

                    <ul>
                        <li><strong>Table:</strong> A collection of related data.</li>
                        <li><strong>Record:</strong> One complete row of information.</li>
                        <li><strong>Field:</strong> One category or column of information.</li>
                    </ul>

                    <h3>Example student table</h3>

                    <pre>
StudentID | Name | Class
001       | Ama  | SHS 3
002       | Kofi | SHS 2
                    </pre>

                    <p>
                        StudentID, Name and Class are fields.
                        Each student's information forms a record.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Design a table for storing student names,
                        student numbers and classes.
                    </div>
                `,
                video: "Database tables records and fields explained"
            },

            {
                title: "Introduction to SQL",
                content: `
                    <h2>Introduction to SQL</h2>

                    <p>
                        SQL means Structured Query Language.
                        It is used to work with relational databases.
                    </p>

                    <h3>Selecting information</h3>

                    <pre>
SELECT * FROM Students;
                    </pre>

                    <h3>Adding information</h3>

                    <pre>
INSERT INTO Students (Name, Class)
VALUES ('Ama', 'SHS 3');
                    </pre>

                    <h3>Filtering information</h3>

                    <pre>
SELECT * FROM Students
WHERE Class = 'SHS 3';
                    </pre>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Write an SQL statement that selects all records
                        from a table called Teachers.
                    </div>
                `,
                video: "SQL tutorial for beginners"
            }

        ]
    },


    computer: {
        title: "Computer Fundamentals",
        description: "Learn about computer systems and their components.",
        lessons: [

            {
                title: "Introduction to Computers",
                content: `
                    <h2>Introduction to Computers</h2>

                    <p>
                        A computer is an electronic device that accepts data,
                        processes it, stores it and produces information.
                    </p>

                    <h3>The information processing cycle</h3>

                    <ul>
                        <li>Input</li>
                        <li>Processing</li>
                        <li>Output</li>
                        <li>Storage</li>
                    </ul>

                    <p>
                        For example, a calculator accepts numbers,
                        processes them and displays an answer.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Explain the four stages of the information
                        processing cycle.
                    </div>
                `,
                video: "Computer fundamentals for beginners"
            },

            {
                title: "Computer Hardware",
                content: `
                    <h2>Computer Hardware</h2>

                    <p>
                        Hardware refers to the physical components
                        of a computer that can be seen and touched.
                    </p>

                    <h3>Examples</h3>

                    <ul>
                        <li>Monitor</li>
                        <li>Keyboard</li>
                        <li>Mouse</li>
                        <li>CPU</li>
                        <li>RAM</li>
                        <li>Storage drive</li>
                    </ul>

                    <h3>Input and output devices</h3>

                    <p>
                        Input devices send data into a computer.
                        Output devices present processed information.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Classify a keyboard, monitor, mouse and printer
                        as input or output devices.
                    </div>
                `,
                video: "Computer hardware components explained"
            },

            {
                title: "Computer Software",
                content: `
                    <h2>Computer Software</h2>

                    <p>
                        Software refers to programs and instructions
                        that tell a computer what to do.
                    </p>

                    <h3>Main categories</h3>

                    <ul>
                        <li><strong>System software:</strong> Manages computer hardware and basic operations.</li>
                        <li><strong>Application software:</strong> Helps users perform specific tasks.</li>
                    </ul>

                    <h3>Examples</h3>

                    <p>
                        Operating systems are system software.
                        Word processors and web browsers are application software.
                    </p>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Give two examples each of system software
                        and application software.
                    </div>
                `,
                video: "System software and application software explained"
            },

            {
                title: "Computer Networks",
                content: `
                    <h2>Computer Networks</h2>

                    <p>
                        A computer network is a group of connected devices
                        that can communicate and share resources.
                    </p>

                    <h3>Types of networks</h3>

                    <ul>
                        <li><strong>LAN:</strong> Local Area Network.</li>
                        <li><strong>MAN:</strong> Metropolitan Area Network.</li>
                        <li><strong>WAN:</strong> Wide Area Network.</li>
                    </ul>

                    <h3>Benefits of networking</h3>

                    <ul>
                        <li>Sharing files.</li>
                        <li>Sharing printers.</li>
                        <li>Communication.</li>
                        <li>Accessing shared services.</li>
                    </ul>

                    <div class="resource-box">
                        <strong>Exercise:</strong>
                        Explain one difference between a LAN and a WAN.
                    </div>
                `,
                video: "Computer networking basics for beginners"
            }

        ]
    }

};


// ==========================================
// 4. COURSE NAVIGATION
// ==========================================

const courseCatalogue = document.getElementById("courseCatalogue");
const learningContent = document.getElementById("learningContent");
const courseGrid = document.getElementById("courseGrid");

const courseTitle = document.getElementById("courseTitle");
const courseDescription = document.getElementById("courseDescription");
const lessonList = document.getElementById("lessonList");
const lessonContent = document.getElementById("lessonContent");

let currentCourse = null;
let currentLesson = 0;


window.openCourse = function(courseId) {

    const course = courses[courseId];

    if (!course) return;

    currentCourse = courseId;
    currentLesson = 0;

    courseCatalogue.style.display = "none";
    learningContent.classList.add("active");

    courseTitle.textContent = course.title;
    courseDescription.textContent = course.description;

    renderLessons();
    showLesson(0);

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

};


// ==========================================
// 5. DISPLAY LESSON LIST
// ==========================================

function renderLessons() {

    const course = courses[currentCourse];

    lessonList.innerHTML = "";

    course.lessons.forEach((lesson, index) => {

        const button = document.createElement("button");

        button.textContent = `${index + 1}. ${lesson.title}`;

        button.addEventListener("click", () => {
            showLesson(index);
        });

        lessonList.appendChild(button);

    });

}


// ==========================================
// 6. DISPLAY SELECTED LESSON
// ==========================================

function showLesson(index) {

    const course = courses[currentCourse];

    if (!course || index < 0 || index >= course.lessons.length) {
        return;
    }

    currentLesson = index;

    const lesson = course.lessons[index];

    lessonContent.innerHTML = lesson.content;

    // Add video tutorial link
    const videoSection = document.createElement("div");

    videoSection.className = "video-section";

    const heading = document.createElement("h3");
    heading.textContent = "Video Tutorial";

    const description = document.createElement("p");
    description.textContent =
        "Watch a video lesson to understand this topic better.";

    const videoLink = document.createElement("a");

    videoLink.href =
        "https://www.youtube.com/results?search_query=" +
        encodeURIComponent(lesson.video);

    videoLink.target = "_blank";
    videoLink.rel = "noopener noreferrer";
    videoLink.className = "lesson-button";
    videoLink.textContent = "Watch Video Tutorial";

    videoSection.appendChild(heading);
    videoSection.appendChild(description);
    videoSection.appendChild(videoLink);

    lessonContent.appendChild(videoSection);

    // Update lesson buttons
    document.querySelectorAll("#lessonList button").forEach((button, i) => {

        button.classList.toggle("active", i === index);

    });

    // Previous and next buttons
    document.getElementById("previousLesson").disabled = index === 0;

    document.getElementById("nextLesson").disabled =
        index === course.lessons.length - 1;

    document.getElementById("previousLesson").style.opacity =
        index === 0 ? "0.5" : "1";

    document.getElementById("nextLesson").style.opacity =
        index === course.lessons.length - 1 ? "0.5" : "1";

    lessonContent.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}


// ==========================================
// 7. PREVIOUS AND NEXT LESSONS
// ==========================================

document.getElementById("previousLesson").addEventListener("click", () => {

    if (currentLesson > 0) {
        showLesson(currentLesson - 1);
    }

});


document.getElementById("nextLesson").addEventListener("click", () => {

    const course = courses[currentCourse];

    if (currentLesson < course.lessons.length - 1) {
        showLesson(currentLesson + 1);
    }

});


// ==========================================
// 8. BACK TO COURSE CATALOGUE
// ==========================================

document.getElementById("backToCourses").addEventListener("click", () => {

    learningContent.classList.remove("active");
    courseCatalogue.style.display = "block";

    currentCourse = null;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

});


// ==========================================
// 9. COURSE SEARCH
// ==========================================

const courseSearch = document.getElementById("courseSearch");

courseSearch.addEventListener("input", () => {

    const searchValue = courseSearch.value.toLowerCase().trim();

    document.querySelectorAll(".course-card").forEach(card => {

        const text = card.textContent.toLowerCase();

        card.style.display = text.includes(searchValue) ? "" : "none";

    });

});


// ==========================================
// 10. CURRENT YEAR
// ==========================================

document.getElementById("learningYear").textContent =
    new Date().getFullYear();


// ==========================================
// 11. FIREBASE MEMBER AUTHENTICATION
// ==========================================

document.body.style.display = "none";

onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    try {

        // Check whether the user is an administrator
        const adminRef = doc(db, "admins", user.uid);
        const adminSnap = await getDoc(adminRef);

        if (adminSnap.exists()) {
            window.location.href = "admin.html";
            return;
        }

        // Check member account
        const memberRef = doc(db, "members", user.uid);
        const memberSnap = await getDoc(memberRef);

        if (!memberSnap.exists()) {
            await signOut(auth);
            window.location.href = "login.html";
            return;
        }

        const memberData = memberSnap.data();

        if (memberData.status !== "approved") {

            await signOut(auth);

            alert("Your membership has not yet been approved.");

            window.location.href = "login.html";
            return;

        }

        // Display member name
        const nameElement = document.getElementById("sidebarMemberName");

        if (nameElement) {
            nameElement.textContent =
                memberData.fullName || "ACC Member";
        }

        // Restore saved theme
        const savedTheme = localStorage.getItem("acc-member-theme");

        if (savedTheme === "light") {
            document.body.classList.add("light-theme");
        }

        document.body.style.display = "";

    } catch (error) {

        console.error("Learning Centre authentication error:", error);

        alert("Unable to verify your account. Please log in again.");

        await signOut(auth);

        window.location.href = "login.html";

    }

});

console.log("ACC Learning Centre loaded successfully.");